local addonName, GetGear = ...

-- Pure Blizzard UI, with no external process or communication bridge.
local function ItemIcon(itemID)
    if type(itemID) == "number" and C_Item and type(C_Item.GetItemIconByID) == "function" then
        local ok, icon = pcall(C_Item.GetItemIconByID,itemID)
        if ok and icon then return icon end
        if GetGear.RequestItemDataOnce then GetGear:RequestItemDataOnce(itemID) end
    end
    return "Interface\\Icons\\INV_Misc_QuestionMark"
end

local function ShowItemTooltip(button)
    if not button.itemID or not GameTooltip then return end
    GameTooltip:SetOwner(button, "ANCHOR_RIGHT")
    if type(GameTooltip.SetItemByID) == "function" then
        GameTooltip:SetItemByID(button.itemID)
    else
        GameTooltip:SetHyperlink("item:" .. tostring(button.itemID))
    end
    if button.gearRecord and not button.previewItem and GetGear.AppendComparisonTooltip then
        GetGear:AppendComparisonTooltip(GameTooltip,button.gearRecord)
    end
    if button.material then
        if GetGear.MaterialName then
            GameTooltip:AddLine("Material: "..GetGear:MaterialName(button.itemID,button.material.name),0.9,0.8,0.6,true)
        end
        local recipe = button.material.recipe
        if recipe then
            GameTooltip:AddLine(" ")
            GameTooltip:AddLine("Can be made from:", 0.9, 0.8, 0.6)
            for _,part in ipairs(recipe.inputs) do
                GameTooltip:AddLine(tostring(part[2]) .. " x " .. (GetGear.MaterialName and GetGear:MaterialName(part[1]) or "ingredient"), 1, 1, 1)
            end
        end
        local have = GetGear:GetMaterialCount(button.itemID)
        GameTooltip:AddLine(" ")
        GameTooltip:AddDoubleLine(button.aggregate and "Total needed for selected objectives" or "Needed for this craft",
            tostring(button.material.amount), 1, 0.83, 0.35, 1, 1, 1)
        GameTooltip:AddDoubleLine("In your bags", have == nil and "Unknown" or tostring(have),
            0.72, 0.78, 0.85, 1, 1, 1)
        if button.itemID==929 then
            GameTooltip:AddLine("Healing Potion output count differs between published Forever sources (1 or 2). Expanded ingredients assume 1 until verified in-game.",1,0.74,0.33,true)
        end
        if GetGear.AppendAltMaterialTooltip then GetGear:AppendAltMaterialTooltip(GameTooltip,button.itemID,button.material.amount) end
    end
    GameTooltip:Show()
end

local function HideItemTooltip()
    if GameTooltip then GameTooltip:Hide() end
end

-- Colour only the class using Blizzard's standard class palette; keep the
-- level and race muted so even the white Priest class name stands out.
local function ColoredCharacterLabel(level, race, class, classToken)
    local muted = "|cffA8B5C5"
    local classColour = RAID_CLASS_COLORS and RAID_CLASS_COLORS[classToken or ""]
    local hex = "FFFFFF"
    if classColour then
        hex = string.format("%02X%02X%02X",
            math.floor((classColour.r or 1)*255+0.5),
            math.floor((classColour.g or 1)*255+0.5),
            math.floor((classColour.b or 1)*255+0.5))
    end
    return muted .. "Level " .. tostring(level or 1)
        .. (race and race ~= "" and " " .. race or "")
        .. "|r |cff" .. hex .. (class or "Class") .. "|r"
end


local function NewIcon(parent, size)
    local button = CreateFrame("Button", nil, parent)
    button:SetSize(size, size)
    local texture = button:CreateTexture(nil, "ARTWORK")
    texture:SetAllPoints()
    button.texture = texture
    local border = button:CreateTexture(nil, "OVERLAY")
    border:SetTexture("Interface\\Buttons\\UI-Quickslot2")
    border:SetPoint("TOPLEFT", -5, 5)
    border:SetPoint("BOTTOMRIGHT", 5, -5)
    button:SetScript("OnEnter", ShowItemTooltip)
    button:SetScript("OnLeave", HideItemTooltip)
    return button
end

local function SetItemIcon(icon, itemID, material, aggregated, record, previewItem)
    icon.gearRecord = record
    icon.previewItem = previewItem and true or false
    icon.itemID = itemID
    icon.material = material
    icon.aggregate = aggregated
    icon.texture:SetTexture(ItemIcon(itemID))
end

local function NewText(parent, template, width, justify)
    local label = parent:CreateFontString(nil, "OVERLAY", template or "GameFontHighlightSmall")
    if width then label:SetWidth(width) end
    label:SetJustifyH(justify or "LEFT")
    label:SetJustifyV("TOP")
    return label
end

local function MeasureText(label, minimum)
    return math.max(minimum or 14, math.ceil(label:GetStringHeight() or minimum or 14))
end

local function NewButton(parent, text, width, height)
    local b = CreateFrame("Button", nil, parent, "UIPanelButtonTemplate")
    b:SetSize(width, height or 23)
    b:SetText(text)
    return b
end

-- Small shared dropdown using the addon's existing buttons and fonts. Each
-- instance reads only its own character preference, including on reopening.
local openSlotMenu
local function NewSlotSelector(parent, name, interface, refresh)
    local button = NewButton(parent, "Slot: All Slots", 166, 22)
    local menu = CreateFrame("Frame", name, button)
    menu:SetSize(166, #GetGear.EquipmentSlotFilters*21+8)
    menu:SetPoint("TOPLEFT", button, "BOTTOMLEFT", 0, -2)
    menu:SetFrameStrata("FULLSCREEN_DIALOG")
    menu:SetClampedToScreen(true)
    menu:EnableMouse(true)
    local bg = menu:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.045, 0.065, 0.10, 1)
    local choices = {}
    for i, entry in ipairs(GetGear.EquipmentSlotFilters) do
        local key = entry[1]
        local choice = NewButton(menu, entry[2], 158, 21)
        choice:SetPoint("TOPLEFT", 4, -4-(i-1)*21)
        choice:SetScript("OnClick", function()
            GetGear:SetEquipmentSlotFilter(interface, key)
            menu:Hide()
            refresh()
        end)
        choices[key] = choice
    end
    menu:Hide()
    if UISpecialFrames then table.insert(UISpecialFrames, name) end
    button:SetScript("OnClick", function()
        if menu:IsShown() then menu:Hide() else
            if openSlotMenu then openSlotMenu:Hide() end
            openSlotMenu=menu
            menu:Show()
        end
    end)
    button:HookScript("OnHide", function() menu:Hide() end)
    function button:Update()
        local selected = GetGear:GetEquipmentSlotFilter(interface)
        self:SetText("Slot: "..GetGear:GetEquipmentSlotFilterLabel(selected))
        for key, choice in pairs(choices) do choice:SetEnabled(key~=selected) end
    end
    return button
end

-- Blizzard's bundled profession textures, without external icon assets.
local PROFESSION_ART = {
    Enchanting = "Interface\\Icons\\Trade_Engraving",
    Tailoring = "Interface\\Icons\\Trade_Tailoring",
    Alchemy = "Interface\\Icons\\Trade_Alchemy",
    Mining = "Interface\\Icons\\Trade_Mining",
    Blacksmithing = "Interface\\Icons\\Trade_BlackSmithing",
    Leatherworking = "Interface\\Icons\\Trade_LeatherWorking",
    Engineering = "Interface\\Icons\\Trade_Engineering",
    ["First Aid"] = "Interface\\Icons\\Spell_Holy_SealOfSacrifice",
}
local function ProfessionSource(gear)
    local name = gear.sourceType
    if name and PROFESSION_ART[name] then return name end
    if gear.profession and PROFESSION_ART[gear.profession] then return gear.profession end
    return nil
end

-- A lightweight gold map pin. We use our own icon, not Blizzard's quest
-- exclamation marks (blue is already reserved for repeatable quests).
local function NewAcquisitionPin(parent, size)
    local b=CreateFrame("Button",nil,parent)
    b:SetSize(size or 23,size or 23)
    local t=b:CreateTexture(nil,"ARTWORK")
    t:SetAllPoints()
    t:SetTexture("Interface\\AddOns\\GetGear\\MapPin")
    b.pinTexture=t
    b:RegisterForClicks("LeftButtonUp","RightButtonUp")
    b:SetScript("OnEnter",function(self)
        local destination=self.gear and GetGear:GetAcquisitionMapTarget(self.gear)
        if not destination or not GameTooltip then return end
        self.pinTexture:SetVertexColor(1,1,0.82)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine(destination.chooseFirst and "Choose acquisition location" or "Open acquisition location",1,0.84,0.42)
        GameTooltip:AddLine((destination.role and destination.role..": " or "")..(destination.label or destination.zone or "Directions"),1,1,1,true)
        if destination.x and destination.y then
            GameTooltip:AddLine((destination.zone or "Destination map") .. " (" .. string.format("%.1f",destination.x) .. ", " .. string.format("%.1f",destination.y) .. ")",0.8,0.85,0.93)
        elseif destination.zone then
            GameTooltip:AddLine(destination.zone .. " - approximate region",0.8,0.85,0.93)
        end
        if destination.kind=="dungeon" then
            GameTooltip:AddLine("Uses a valid client entrance first, then a published outdoor approach. Exact portal/access and boss-floor positions are not assumed.",0.8,0.85,0.93,true)
            if destination.approachOnly then
                GameTooltip:AddLine("Marks the exterior approach for this source; the quest giver's exact local position is unresolved.",1,0.70,0.32,true)
            end
        elseif destination.bounds and not destination.x then
            GameTooltip:AddLine("Published area, not an exact NPC position.",0.8,0.85,0.93,true)
        end
        if destination.verification=="legacy-reference" then
            GameTooltip:AddLine("Classic location; verify in Forever",1,0.70,0.32,true)
        elseif destination.verification~="client" then
            GameTooltip:AddLine("Published reference; current presence, stock, loot and access remain unverified.",1,0.70,0.32,true)
        end
        if destination.chainUnresolved then
            GameTooltip:AddLine("Quest route incomplete: opens known stages and unresolved prerequisite details.",1,0.70,0.32,true)
        end
        if destination.requirements and destination.requirements~="" then
            GameTooltip:AddLine(destination.requirements,0.85,0.87,0.92,true)
        end
        if (destination.choiceCount or 0)>1 then
            GameTooltip:AddLine("Right-click for other locations ("..destination.choiceCount..").",0.65,0.76,0.88,true)
        end
        GameTooltip:AddLine("Opens the map or written directions. Your existing waypoint is preserved.",0.65,0.76,0.88,true)
        GameTooltip:Show()
    end)
    b:SetScript("OnLeave",function(self)
        self.pinTexture:SetVertexColor(1,1,1)
        HideItemTooltip()
    end)
    b:SetScript("OnClick",function(self,button)
        if self.gear then GetGear:OpenAcquisitionMap(self.gear,nil,self,button=="RightButton") end
    end)
    return b
end

local function AssignAcquisitionPin(b,gear)
    local target=GetGear.GetAcquisitionMapTarget and GetGear:GetAcquisitionMapTarget(gear)
    if target then
        b.gear=gear
        b.destination=target
        b:Show()
    else
        b.gear=nil
        b.destination=nil
        b:Hide()
    end
end

-- A single lazy popup for source choices or directions. No additional controls
-- or permanent text are added to compact objective rows.
local navigationPopup
function GetGear:HideAcquisitionNavigation()
    if navigationPopup then navigationPopup:Hide() end
end
local function NavigationPopup()
    if navigationPopup then return navigationPopup end
    local f=CreateFrame("Frame","GetGearNavigationPopup",UIParent,"BackdropTemplate")
    f:SetSize(410,330);f:SetPoint("CENTER");f:SetFrameStrata("DIALOG");f:SetClampedToScreen(true)
    f:SetBackdrop({bgFile="Interface\\DialogFrame\\UI-DialogBox-Background",edgeFile="Interface\\Tooltips\\UI-Tooltip-Border",tile=true,tileSize=16,edgeSize=16,insets={left=4,right=4,top=4,bottom=4}})
    f.title=NewText(f,"GameFontNormal",350);f.title:SetPoint("TOPLEFT",14,-14)
    local close=NewButton(f,"X",24,22);close:SetPoint("TOPRIGHT",-8,-8);close:SetScript("OnClick",function() f:Hide() end)
    f.scroll=CreateFrame("ScrollFrame",nil,f,"UIPanelScrollFrameTemplate");f.scroll:SetPoint("TOPLEFT",14,-44);f.scroll:SetPoint("BOTTOMRIGHT",-30,42)
    f.content=CreateFrame("Frame",nil,f.scroll);f.content:SetSize(360,240);f.scroll:SetScrollChild(f.content)
    f.text=NewText(f.content,"GameFontHighlightSmall",350);f.text:SetPoint("TOPLEFT",0,0)
    f.buttons={}
    f.previous=NewButton(f,"Previous",88,23);f.previous:SetPoint("BOTTOMLEFT",14,12)
    f.next=NewButton(f,"Next",88,23);f.next:SetPoint("BOTTOMRIGHT",-14,12)
    if type(UISpecialFrames)=="table" then table.insert(UISpecialFrames,"GetGearNavigationPopup") end
    f:Hide();navigationPopup=f
    return f
end
function GetGear:ShowAcquisitionDirections(gear,target,anchor,reason)
    local f=NavigationPopup()
    f.title:SetText(gear.name or "Acquisition directions")
    for _, b in ipairs(f.buttons) do b:Hide() end
    f.previous:Hide();f.next:Hide();f.text:Show()
    local text=(reason and reason.."\n\n" or "")..self:GetAcquisitionDirections(gear)
    if target then
        text=(reason and reason.."\n\n" or "")..(target.role or "Destination")..": "..(target.label or target.zone or "Unresolved")
            ..(target.zone and " — "..target.zone or "").."\n"..(target.instructions or "")
            .."\n\n"..self:GetAcquisitionDirections(gear)
    end
    if gear.instructions and gear.instructions~="" then text=text.."\n\n"..gear.instructions end
    local research=gear.acquisitionResearch
    if research and research.details then text=text.."\n\n"..research.details end
    f.text:SetText(text);f.content:SetHeight(MeasureText(f.text,240));f.scroll:SetVerticalScroll(0);f:Show()
end
function GetGear:ShowAcquisitionChoices(gear,choices,anchor)
    local f=NavigationPopup()
    f.title:SetText("Where to obtain "..(gear.name or "this item"))
    f.text:Hide();f.content:SetHeight(240);f.scroll:SetVerticalScroll(0)
    local page=1
    local function render()
        for _, b in ipairs(f.buttons) do b:Hide() end
        local first=(page-1)*6+1
        for n=1,6 do
            local target=choices[first+n-1]
            if not target then break end
            local b=f.buttons[n]
            if not b then b=NewButton(f.content,"",350,34);b:SetPoint("TOPLEFT",0,-(n-1)*38);f.buttons[n]=b end
            b:SetText((target.role or "Location")..": "..(target.label or target.zone or "Directions")..(target.zone and " — "..target.zone or ""))
            b:SetScript("OnClick",function() f:Hide();GetGear:OpenAcquisitionMap(gear,target.id,anchor) end)
            b:SetScript("OnEnter",function(self)
                if not GameTooltip then return end
                GameTooltip:SetOwner(self,"ANCHOR_RIGHT");GameTooltip:AddLine(target.label or "Location",1,0.84,0.42,true)
                if target.requirements and target.requirements~="" then GameTooltip:AddLine(target.requirements,1,1,1,true) end
                GameTooltip:AddLine("Published source; current availability unverified.",1,0.7,0.32,true);GameTooltip:Show()
            end)
            b:SetScript("OnLeave",HideItemTooltip);b:Show()
        end
        f.previous:SetEnabled(page>1);f.next:SetEnabled(page*6<#choices);f.previous:Show();f.next:Show()
    end
    f.previous:SetScript("OnClick",function() if page>1 then page=page-1;render() end end)
    f.next:SetScript("OnClick",function() if page*6<#choices then page=page+1;render() end end)
    render();f:Show()
end

local function NewProfessionIcon(parent, size)
    local button = CreateFrame("Button", nil, parent)
    button:SetSize(size or 18, size or 18)
    local texture = button:CreateTexture(nil,"ARTWORK")
    texture:SetAllPoints()
    button.icon = texture
    button:SetScript("OnEnter", function(self)
        if self.profession and GameTooltip then
            GameTooltip:SetOwner(self, "ANCHOR_RIGHT")
            GameTooltip:AddLine(self.profession, 1, 0.82, 0.35)
            if self.required then
                local current = GetGear:GetProfessionSkill(self.profession)
                local have = current == nil and "Not learned" or tostring(current)
                GameTooltip:AddDoubleLine("Skill", have .. " / " .. self.required, 1, 1, 1, 1, 1, 1)
            end
            GameTooltip:Show()
        end
    end)
    button:SetScript("OnLeave", HideItemTooltip)
    return button
end
local function SetProfessionIcon(button, profession, required)
    if not profession or not PROFESSION_ART[profession] then button:Hide(); return end
    button.profession, button.required = profession, required
    button.icon:SetTexture(PROFESSION_ART[profession])
    button:Show()
end
local function UpdateProfessionSkill(icon, label, gear, showRequiredProfession, previewMode)
    if not gear.profession then
        icon:Hide(); label:Hide(); return false
    end
    local published
    if GetGear.GetRecipeSkillRequirement then published=GetGear:GetRecipeSkillRequirement(gear) end
    local required=published or gear.professionSkillRequired
    if not published and gear.recipeLearnSkillEvidence=="unverified" then required=nil end
    local provisional=not published and gear.recipeLearnSkillProvisional==true
    if previewMode then
        -- This is an alternate class/level; the actual player's skill and
        -- known recipes must not be presented as the preview character's.
        if required then
            label:SetText(gear.profession .. " " .. tostring(required) ..
                (provisional and "? (reported)" or " required"))
        elseif gear.professionLearnSource == "Trainer" or gear.professionSkillEstimate or gear.recipeLearnMethod=="trainer" then
            label:SetText(gear.profession .. " - Trainer (verify skill)")
        else
            label:SetText(gear.profession .. " - skill unverified")
        end
        label:SetTextColor(1,0.82,0.46)
        icon:Hide()
        label:Show()
        return true
    end
    -- A known craft recipe is stronger evidence than an external skill
    -- requirement. Lookup is tri-state: nil means the client has not supplied
    -- trustworthy learning data, not that the player lacks the recipe.
    local learned = GetGear.GetRecipeKnowledge and GetGear:GetRecipeKnowledge(gear)
    local trainer = gear.professionLearnSource == "Trainer" or
        gear.professionSkillEstimate ~= nil or gear.recipeLearnMethod=="trainer"
    if learned ~= true and required == nil and not trainer then
        icon:Hide()
        label:SetText(gear.profession .. " - skill unverified")
        label:SetTextColor(1,0.77,0.38)
        label:Show()
        return true
    end
    local current = GetGear:GetProfessionSkill(gear.profession)
    if showRequiredProfession then
        if learned == true then
            label:SetText(gear.profession .. (required and " "..required or "") .. " - Learned")
        elseif required then
            label:SetText(gear.profession .. " " .. tostring(required) .. (provisional and "?" or ""))
        else
            label:SetText(gear.profession .. " - Trainer")
        end
    else
        if learned == true then
            label:SetText(gear.profession .. (required and " "..required or "") .. " - Learned")
        elseif required then
            label:SetText((current == nil and "-" or tostring(current)) .. "/" .. tostring(required) .. (provisional and "?" or ""))
        else
            label:SetText(gear.profession .. " - Trainer")
        end
    end
    if learned == true or (required and not provisional and current and current >= required) then
        label:SetTextColor(0.38,0.90,0.53)
    else
        label:SetTextColor(1,0.77,0.38)
    end
    -- The overlay intentionally hides this icon; the detailed window keeps
    -- its existing icon for the progress tooltip when a requirement exists.
    if required and not (learned == true) then
        SetProfessionIcon(icon, gear.profession, required)
    else
        icon:Hide()
    end
    label:Show()
    return true
end

local function Describe(gear, previewMode)
    local hasSource = type(gear.source)=="string" and gear.source~=""
    local desc = (hasSource and (gear.source .. ": ") or "") .. (gear.instructions or "")
    local supplement=GetGear.RecipeEvidence and GetGear.RecipeEvidence[gear.itemID]
    local normalized=supplement and GetGear:GetNormalizedRecipeData(gear)
    local documented=normalized and normalized.sourceConfidence=="documented"
    if documented then
        desc=(GetGear:GetAcquisitionSummary(gear) or "Recipe: documented source").."\n"..(gear.instructions or "")
    end
    if gear.notes and gear.notes ~= "" then desc = desc .. "\n" .. gear.notes end
    local research=gear.acquisitionResearch
    if research and (research.recipeReference or research.equipmentReference) and research.sourceSummary then
        if not documented then desc=desc.."\n"..research.sourceSummary end
        if research.details and research.details~="" then
            desc=desc.."\n"..research.details
        end
    end
    -- Keep raw multi-faction research in the catalogue, but direct the player
    -- only through eligible routes. Shared directions retain per-source gates.
    if GetGear.GetFactionAcquisitionDescription then
        local eligible=GetGear:GetFactionAcquisitionDescription(gear)
        if eligible then desc=eligible end
    end
    if gear.suitabilityWarning and gear.suitabilityWarning~="" and
        not desc:find(gear.suitabilityWarning,1,true) then
        desc=desc.."\n"..gear.suitabilityWarning
    end
    if gear.recipeLearningAvailability=="disputed" and
        not desc:lower():find("trainer teaching route",1,true) and
        not desc:lower():find("trainer teaching as well",1,true) and
        not desc:lower():find("method disputed",1,true) then
        desc=desc.."\n|cffffba63Recipe teaching availability is disputed in Forever sources. " ..
            "Check the current trainer/recipe window before relying on this route.|r"
    end
    if gear.confidence == "classic-reference" and not desc:lower():find("classic",1,true) then
        desc = desc .. "\n|cffffba63Item source is Classic-reference only, not a confirmed Forever reward or drop. Any map pin locates the destination, not proof of the item.|r"
    elseif gear.acquisitionConfidence == "client" and gear.profession
        and (not gear.recipeLearnMethod or gear.recipeLearnMethod=="unverified") then
        desc = desc .. "\n|cffffba63Recipe exists in client; learning source is not verified.|r"
    end
    if gear.confidence == "client" and gear.acquisitionConfidence == "classic-reference" then
        desc = desc .. "\n|cffffba63Item stats exist in the client; the listed seller/source is Classic-reference only.|r"
    end
    if previewMode and type(gear.races)=="table" and #gear.races>0 then
        desc = desc .. "\n|cffffba63Race-restricted: " .. table.concat(gear.races, ", ") .. ".|r"
    end
    if GetGear.GetAcquisitionDirections then
        local directions=GetGear:GetAcquisitionDirections(gear)
        if directions~="" then desc=desc.."\n\n|cffffd36aWhere to go|r\n"..directions end
    end
    return desc
end

-- The compact overlay already identifies the profession and trainer/skill
-- state beside MATERIALS. The acquisition pin supplies mapped recipe vendors.
-- Don't repeat those facts in a second paragraph. Keep method information not
-- shown by the heading (patterns and initial recipes), and significant source
-- warnings even when a location pin exists. The detailed Guide stays complete.
local function DescribeOverlay(gear, hasLocationButton)
    -- The shared compact formatter already includes the acquisition method,
    -- meaningful restrictions and uncertainty. Expanding must not append a
    -- second raw/provenance paragraph; the full Guide retains those details.
    if GetGear.GetAcquisitionSummary and GetGear:GetAcquisitionSummary(gear) then return nil end
    if gear.profession then
        if gear.recipeLearningAvailability=="disputed" then
            return "Recipe teaching method disputed in Forever; check trainer/pattern availability."
        end
        if gear.acquisitionConfidence=="classic-reference" or gear.confidence=="classic-reference" then
            return "Recipe source based on Classic; not yet confirmed in Forever."
        end
        -- An existing map button already shows the vendor/destination.
        if hasLocationButton then return nil end
        -- A vendor can be documented even when no usable navigation pin exists.
        if gear.recipeVendor and gear.recipeVendor~="" then
            return "Pattern vendor: "..gear.recipeVendor.."."
        end
        -- A bare "pattern/plans required" message is not actionable.
        -- Show a named vendor above when known, or a mapped pin; otherwise
        -- leave detailed learning information to the Guide instead of filler.
        if gear.recipeLearnMethod=="pattern" then
            return nil
        end
        if gear.recipeLearnMethod=="initial" then
            return "Recipe included when learning the profession (client-listed)."
        end
        -- Trainer recipes are already labelled "Profession - Trainer" in the
        -- MATERIALS header, or "Learned" if the client knows the recipe.
        return nil
    end
    -- Source names may contain periods (Mr. Smite) or ellipses in quest
    -- titles (What Comes Around...). Never split on punctuation: the
    -- overlay description text wraps, with its height measured dynamically.
    local source = tostring(gear.source or gear.sourceType or "Unknown source")
    local short=source:match("^([^\r\n]+)") or source
    local last=short:sub(-1)
    local text="Source: "..short..((last=="." or last=="!" or last=="?") and "" or ".")
    if (gear.confidence=="classic-reference"
        or gear.acquisitionConfidence=="classic-reference")
        and not source:lower():find("classic",1,true)
        and not source:lower():find("unverified",1,true)
        and not source:lower():find("unconfirmed",1,true) then
        text=text.." Source not yet verified in Forever."
    end
    return text
end

-- Benefit icons deliberately use client-bundled Blizzard icon art.
local function NewBenefit(parent)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(282, 22)
    local texture = holder:CreateTexture(nil, "ARTWORK")
    texture:SetSize(19, 19)
    texture:SetPoint("LEFT", 0, 0)
    local label = NewText(holder, "GameFontHighlightSmall", 251)
    label:SetPoint("LEFT", texture, "RIGHT", 7, 0)
    holder.icon, holder.label = texture, label
    return holder
end

local function SetBenefit(widget, benefit, x, y, parent)
    widget:ClearAllPoints()
    widget:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y)
    widget.icon:SetTexture(benefit.icon or "Interface\\Icons\\INV_Misc_QuestionMark")
    widget.label:SetText(benefit.text)
    widget:Show()
end

local function NewReagent(parent, compact)
    local holder = CreateFrame("Frame", nil, parent)
    holder:SetSize(compact and 292 or 324, compact and 27 or 34)
    local quantity = NewText(holder, compact and "GameFontHighlightSmall" or "GameFontNormal", compact and 43 or 42, "RIGHT")
    quantity:SetPoint("LEFT", 0, 0)
    local icon = NewIcon(holder, compact and 22 or 29)
    icon:SetPoint("LEFT", quantity, "RIGHT", compact and 5 or 7, 0)
    local arrow = CreateFrame("Button", nil, holder)
    arrow:SetSize(18, 18)
    -- Anchored beside the reagent name in UpdateReagent. Do not reserve a
    -- column before the name: all top-level quantities/icons/names align.
    -- No opaque box: gold arrow on a transparent 18px hit area.
    local arrowGlyph = NewText(arrow, "GameFontNormalSmall", 18, "CENTER")
    arrowGlyph:SetPoint("CENTER",0,0)
    arrowGlyph:SetTextColor(1,0.76,0.33)
    arrow.arrowGlyph = arrowGlyph
    arrow:SetScript("OnEnter", function(self)
        arrowGlyph:SetTextColor(1, 0.94, 0.62)
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine(self.collapsed and "Expand ingredients" or "Collapse ingredients",1,0.82,0.35)
        GameTooltip:Show()
    end)
    arrow:SetScript("OnLeave",function()
        arrowGlyph:SetTextColor(1,0.76,0.33)
        HideItemTooltip()
    end)
    local name = NewText(holder, "GameFontHighlightSmall", compact and 198 or 239)
    name:SetPoint("LEFT",icon,"RIGHT",7,0)
    local hit = CreateFrame("Button", nil, holder)
    hit:SetPoint("TOPLEFT", name, "TOPLEFT", 0, 4)
    hit:SetSize(compact and 194 or 225, compact and 26 or 30)
    hit:SetScript("OnEnter", ShowItemTooltip)
    hit:SetScript("OnLeave", HideItemTooltip)
    return {frame=holder, count=quantity, icon=icon, name=name, hit=hit, arrow=arrow, compact=compact}
end

local function UpdateReagent(widget, mat, x, y, parent, aggregated, previewMode)
    widget.frame:ClearAllPoints()
    widget.frame:SetPoint("TOPLEFT", parent, "TOPLEFT", x, -y)
    local parentWidth = (parent.GetWidth and parent:GetWidth()) or 316
    local available = math.max(185, parentWidth - x - 8)
    widget.frame:SetWidth(available)
    SetItemIcon(widget.icon, mat.itemID, mat, aggregated)
    widget.hit.itemID, widget.hit.material, widget.hit.aggregate = mat.itemID, mat, aggregated
    local function ToggleReagent()
        if GetGear.db and mat.collapseKey then
            local setting=GetGear.db.overlay.dependencyExpanded
            setting[mat.collapseKey]=not setting[mat.collapseKey] or nil
            GetGear:RefreshAll()
        end
    end
    widget.name:ClearAllPoints()
    -- The icon/name column is aligned on every top-level material row. Only
    -- true crafting dependencies are indented (via the x value passed in).
    widget.name:SetPoint("LEFT",widget.icon,"RIGHT",7,0)
    local leftSpace = (widget.compact and (43+5+22+7) or (42+7+29+7))
    local expandable = mat.hasChildren and mat.collapseKey
    local maxNameWidth = math.max(65,available-leftSpace-(expandable and 25 or 5))
    widget.name:SetWidth(maxNameWidth)
    local materialLabel=GetGear.MaterialName and GetGear:MaterialName(mat.itemID,mat.name) or mat.name
    if not previewMode and not widget.compact and GetGear.GetAltMaterialSummary then
        local stock=GetGear:GetAltMaterialSummary(mat.itemID)
        if stock and stock.bank+stock.alts>0 then
            materialLabel=materialLabel.." |cff91bedb(bank "..stock.bank..", alts "..stock.alts..")|r"
        end
    end
    widget.name:SetText(materialLabel)
    if expandable and not previewMode then
        widget.arrow.collapsed = mat.collapsed
        widget.arrow.arrowGlyph:SetText(mat.collapsed and ">" or "v")
        widget.arrow:SetScript("OnClick",ToggleReagent)
        -- Keep the arrow immediately after the visible name, not right-justified.
        -- First measure at the available width, then constrain if necessary.
        local measured = widget.name:GetStringWidth() or maxNameWidth
        widget.name:SetWidth(math.max(50,math.min(maxNameWidth,math.ceil(measured)+2)))
        widget.arrow:ClearAllPoints()
        widget.arrow:SetPoint("LEFT",widget.name,"RIGHT",3,0)
        widget.arrow:Show()
        widget.hit:SetScript("OnClick",ToggleReagent)
    else
        widget.arrow:Hide()
        widget.hit:SetScript("OnClick",nil)
    end
    widget.hit:SetWidth(widget.name:GetWidth())
    local have = previewMode and nil or GetGear:GetMaterialCount(mat.itemID)
    if previewMode then
        widget.count:SetText(tostring(mat.amount) .. " x")
        widget.count:SetTextColor(1, 0.79, 0.40)
        widget.name:SetTextColor(0.89, 0.89, 0.89)
        widget.icon.texture:SetDesaturated(false)
        widget.icon.texture:SetVertexColor(1, 1, 1)
    else
        widget.count:SetText((have == nil and "?" or tostring(have)) .. "/" .. tostring(mat.amount))
    end
    if not previewMode and have ~= nil and have >= mat.amount then
        widget.count:SetTextColor(0.38, 0.90, 0.53)
        widget.name:SetTextColor(0.43, 0.89, 0.57)
        widget.icon.texture:SetDesaturated(false)
        widget.icon.texture:SetVertexColor(1, 1, 1)
    elseif not previewMode then
        widget.count:SetTextColor(1, 0.79, 0.40)
        widget.name:SetTextColor(0.89, 0.89, 0.89)
        widget.icon.texture:SetDesaturated(true)
        widget.icon.texture:SetVertexColor(0.78, 0.78, 0.78)
    end
    widget.frame:Show()
end

-- Native resizing with a small, discoverable bottom-right grab handle.
local function AllowResizing(frame,minW,minH,maxW,maxH)
    frame:SetResizable(true)
    if type(frame.SetResizeBounds)=="function" then
        frame:SetResizeBounds(minW,minH,maxW,maxH)
    else
        if type(frame.SetMinResize)=="function" then frame:SetMinResize(minW,minH) end
        if type(frame.SetMaxResize)=="function" then frame:SetMaxResize(maxW,maxH) end
    end
    local grip=CreateFrame("Button",nil,frame)
    grip:SetSize(21,21)
    grip:SetPoint("BOTTOMRIGHT", -2, 2)
    grip:SetFrameLevel(frame:GetFrameLevel()+15)
    grip:SetNormalTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Up")
    grip:SetHighlightTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Highlight")
    grip:SetPushedTexture("Interface\\ChatFrame\\UI-ChatIM-SizeGrabber-Down")
    grip:SetScript("OnMouseDown",function(self,button)
        if button=="LeftButton" then frame.isSizing=true;frame:StartSizing("BOTTOMRIGHT") end
    end)
    grip:SetScript("OnMouseUp",function(self,button)
        if button=="LeftButton" and frame.isSizing then
            frame:StopMovingOrSizing()
            frame.isSizing=false
            if frame.afterResize then frame:afterResize() end
        end
    end)
    grip:SetScript("OnHide",function()
        if frame.isSizing then frame:StopMovingOrSizing();frame.isSizing=false end
    end)
    grip:SetScript("OnUpdate",function()
        if frame.isSizing and type(IsMouseButtonDown)=="function" and not IsMouseButtonDown("LeftButton") then
            frame:StopMovingOrSizing()
            frame.isSizing=false
            if frame.afterResize then frame:afterResize() end
        end
    end)
    return grip
end

-- =====================================================================
-- Detailed planning window: useful for descriptions, hidden items and settings.
-- =====================================================================
local window = CreateFrame("Frame", "GetGear_MainWindow", UIParent, "BasicFrameTemplateWithInset")
window:SetSize(780, 608)
-- The detailed guide is a foreground planning window, not part of the
-- translucent tracker. DIALOG sits above normal bag/addon frames while
-- higher strata remain available to Blizzard confirmations and tooltips.
window:SetFrameStrata("DIALOG")
if window.SetToplevel then window:SetToplevel(true) end
-- The Blizzard BasicFrameTemplate has translucent regions. An opaque BACKGROUND
-- texture fills the entire frame behind its title bar, borders and content,
-- so UI windows underneath cannot bleed through the guide. It is deliberately
-- independent of the tracker backgroundOpacity slider.
local detailBackdrop = window:CreateTexture(nil, "BACKGROUND", nil, -8)
detailBackdrop:SetAllPoints(window)
detailBackdrop:SetColorTexture(0.045, 0.065, 0.10, 1)
if window.SetClampedToScreen then window:SetClampedToScreen(true) end
window:SetPoint("CENTER")
window:SetMovable(true)
window:EnableMouse(true)
-- Do not make the entire guide draggable. A large drag target can accidentally
-- engage WoW's mouse capture when clicking/Alt-Tabbing across the window.
-- Restrict movement to its title bar; the close button is not covered.
local titleDrag=CreateFrame("Button",nil,window)
titleDrag:SetPoint("TOPLEFT",window,"TOPLEFT",26,-3)
titleDrag:SetPoint("TOPRIGHT",window,"TOPRIGHT",-52,-3)
titleDrag:SetHeight(23)
titleDrag:SetFrameLevel(window:GetFrameLevel()+4)
local titleDragging=false
local function StopTitleDrag()
    if not titleDragging then return end
    titleDragging=false
    window:StopMovingOrSizing()
    if GetGear.db then
        GetGear.db.detail.x, GetGear.db.detail.y = window:GetLeft(), window:GetTop()
    end
end
titleDrag:SetScript("OnMouseDown",function(self,button)
    if button=="LeftButton" and not titleDragging then
        titleDragging=true
        window:StartMoving()
    end
end)
titleDrag:SetScript("OnMouseUp",function(self,button)
    if button=="LeftButton" then StopTitleDrag() end
end)
titleDrag:SetScript("OnUpdate",function()
    if titleDragging and type(IsMouseButtonDown)=="function" and not IsMouseButtonDown("LeftButton") then
        StopTitleDrag()
    end
end)
titleDrag:SetScript("OnHide",StopTitleDrag)
window:Hide()
if window.TitleText then window.TitleText:SetText("GetGear") end
if UISpecialFrames then table.insert(UISpecialFrames, "GetGear_MainWindow") end

local levelText = NewText(window, "GameFontNormalLarge")
levelText:SetPoint("TOPLEFT", 18, -36)
local subtitle = NewText(window, "GameFontHighlightSmall", 720)
subtitle:SetPoint("TOPLEFT", levelText, "BOTTOMLEFT", 0, -7)
subtitle:SetText("Hover for stats. Equipped gear appears in Completed; older and outclassed gear in Earlier Gear.")

-- Session-only detailed-window planning state. Never saved and never used
-- in GetGear.Gear / GetItems / RefreshOverlay or character progression.
local preview = {active=false, classToken="ROGUE", level=60, full=true}
local previewClasses = {
    "PRIEST", "WARLOCK", "MAGE", "DRUID", "WARRIOR",
    "ROGUE", "PALADIN", "HUNTER", "SHAMAN",
}
local previewNames = {
    PRIEST="Priest", WARLOCK="Warlock", MAGE="Mage", DRUID="Druid",
    WARRIOR="Warrior", ROGUE="Rogue", PALADIN="Paladin",
    HUNTER="Hunter", SHAMAN="Shaman",
}
local function PreviewEntries()
    local all = GetGear:GetPreviewRecommendations(preview.classToken)
    local visible = {}
    for _, gear in ipairs(all) do
        if (preview.full or (gear.targetLevel and gear.targetLevel <= preview.level))
            and (not GetGear.ShouldDisplayGear or GetGear:ShouldDisplayGear(gear,preview.classToken,"preview")) then
            visible[#visible+1] = gear
        end
    end
    table.sort(visible, function(a,b)
        if a.targetLevel ~= b.targetLevel then return a.targetLevel < b.targetLevel end
        if (a.slot or "") ~= (b.slot or "") then return (a.slot or "") < (b.slot or "") end
        if (a.name or "") ~= (b.name or "") then return (a.name or "") < (b.name or "") end
        return (a.itemID or 0) < (b.itemID or 0)
    end)
    return visible
end

local scroll
local tabs, tabNames = {}, {
    -- Navigation belongs on the top row in progression order; stay within
    -- the 720px minimum window width (666px including 5px gaps).
    {"earlier", "Earlier Gear", 108}, {"available", "Available Now", 102},
    {"upcoming", "Next 5 Levels", 126}, {"completed", "Completed / Skipped", 151},
    {"hidden", "Hidden", 78}, {"bags", "Bags", 76},
}
for i, entry in ipairs(tabNames) do
    local btn = NewButton(window, entry[2], entry[3], 24)
    if i == 1 then btn:SetPoint("TOPLEFT", 18, -91)
    else btn:SetPoint("LEFT", tabs[i-1], "RIGHT", 5, 0) end
    local tab = entry[1]
    btn:SetScript("OnClick", function()
        GetGear.activeTab = tab
        scroll:SetVerticalScroll(0)
        GetGear:RefreshUI()
    end)
    tabs[i] = btn
end
local optionsButton = NewButton(window, "Display settings", 130, 24)
optionsButton:SetPoint("TOPLEFT", 18, -122)
optionsButton:SetScript("OnClick", function() GetGear:ShowSettings() end)

-- Preview controls exist ONLY in the detailed guide, not the tracker overlay.
local startPreview = NewButton(window, "Preview guide", 126, 24)
startPreview:SetPoint("TOPLEFT", 155, -122)
-- Detailed-window-only entry point for cached bags/bank diagnostics.
local altInventoryButton = NewButton(window, "Alt inventory", 126, 24)
altInventoryButton:SetPoint("TOPLEFT", 289, -122)
altInventoryButton:SetScript("OnClick", function()
    if GetGear.ShowAltInventoryBrowser then GetGear:ShowAltInventoryBrowser() end
end)
altInventoryButton:SetScript("OnEnter", function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Account inventory tracker",1,0.83,0.35)
    GameTooltip:AddLine("Open the searchable inventory browser inside this guide.",1,1,1,true)
    GameTooltip:AddLine("View bags, banks and saved alt inventories. Click an item for a character breakdown.",0.75,0.84,1,true)
    GameTooltip:Show()
end)
altInventoryButton:SetScript("OnLeave", HideItemTooltip)
local previewHeading = NewText(window, "GameFontNormal", 462)
previewHeading:SetPoint("TOPLEFT", 18, -96)
previewHeading:SetText("|cffedc774GUIDE PREVIEW|r  |cffb6c3d3(read-only)|r")
local exitPreview = NewButton(window, "Return to character", 137, 24)
exitPreview:SetPoint("TOPLEFT", 489, -91)
local previewClassButton = NewButton(window, "Class: Rogue", 151, 24)
previewClassButton:SetPoint("TOPLEFT", 18, -122)
local previewMinus = NewButton(window, "-", 28, 24)
previewMinus:SetPoint("TOPLEFT", 176, -122)
local previewLevelLabel = NewText(window, "GameFontHighlightSmall", 24)
previewLevelLabel:SetPoint("TOPLEFT", 210, -126)
previewLevelLabel:SetText("Lv")
local previewLevel = CreateFrame("EditBox", nil, window, "InputBoxTemplate")
previewLevel:SetSize(45, 22)
previewLevel:SetPoint("TOPLEFT", 239, -122)
previewLevel:SetAutoFocus(false)
previewLevel:SetNumeric(true)
previewLevel:SetMaxLetters(2)
previewLevel:SetText("60")
local previewPlus = NewButton(window, "+", 28, 24)
previewPlus:SetPoint("TOPLEFT", 290, -122)
local previewFullButton = NewButton(window, "Full 1-60: ON", 156, 24)
previewFullButton:SetPoint("TOPLEFT", 328, -122)

-- Preview shares the detailed-window second toolbar row with Display
-- settings. Keep the settings control immediately after Full 1-60 rather
-- than at the Class selector's coordinates (Beta5 regression prevention).
local function PositionDisplaySettingsForPreview(active)
    optionsButton:ClearAllPoints()
    if active then
        optionsButton:SetPoint("LEFT", previewFullButton, "RIGHT", 8, 0)
    else
        optionsButton:SetPoint("TOPLEFT", 18, -122)
    end
end

startPreview:SetScript("OnClick", function()
    preview.active = true
    preview.classToken = GetGear.GuideDefinitions[GetGear.classToken] and GetGear.classToken or "ROGUE"
    preview.level = 60
    preview.full = true
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
exitPreview:SetScript("OnClick", function()
    preview.active = false
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
previewClassButton:SetScript("OnClick", function()
    for i, class in ipairs(previewClasses) do
        if class == preview.classToken then
            preview.classToken = previewClasses[(i % #previewClasses)+1]
                    break
        end
    end
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
local function SetPreviewLevel(delta)
    preview.level = math.max(1, math.min(60, preview.level+delta))
    preview.full = false
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end
previewMinus:SetScript("OnClick", function() SetPreviewLevel(-1) end)
previewPlus:SetScript("OnClick", function() SetPreviewLevel(1) end)
previewLevel:SetScript("OnEnterPressed", function(self)
    local chosen = tonumber(self:GetText())
    if chosen then
        preview.level = math.max(1, math.min(60, math.floor(chosen)))
        preview.full = false
        scroll:SetVerticalScroll(0)
    end
    self:ClearFocus()
    GetGear:RefreshUI()
end)
previewLevel:SetScript("OnEscapePressed", function(self)
    self:ClearFocus()
    self:SetText(tostring(preview.level))
end)
previewFullButton:SetScript("OnClick", function()
    preview.full = not preview.full
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
previewClassButton:SetScript("OnEnter", function(self)
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Cycle through all nine class guides",1,0.82,0.35)
    GameTooltip:AddLine("A race-restricted item is marked in its description.",1,1,1,true)
    GameTooltip:Show()
end)
previewClassButton:SetScript("OnLeave",HideItemTooltip)
local statusText = NewText(window, "GameFontHighlightSmall", 720, "RIGHT")
local detailSlot = NewSlotSelector(window, "GetGear_DetailSlotMenu", "detail",
    function() GetGear:RefreshUI() end)
detailSlot:SetPoint("TOPLEFT", 18, -152)
statusText:SetPoint("TOPLEFT", detailSlot, "TOPRIGHT", 12, -3)
statusText:SetPoint("TOPRIGHT", window, "TOPRIGHT", -38, -155)
local detailContext = NewText(window, "GameFontHighlightSmall", 440, "RIGHT")
detailContext:SetPoint("TOPRIGHT", -38, -184)
-- A full 1-60 catalogue can contain thousands of rows per class.
-- Keep only one bounded page of detailed WoW frames alive at a time.
local DETAIL_PAGE_SIZE = 40
local detailPage, detailViewKey = 1, nil
local pagePrev = NewButton(window, "< Prev", 72, 22)
pagePrev:SetPoint("TOPLEFT", 18, -181)
local pageNext = NewButton(window, "Next >", 72, 22)
pageNext:SetPoint("LEFT", pagePrev, "RIGHT", 62, 0)
local pageLabel = NewText(window, "GameFontHighlightSmall", 58, "CENTER")
pageLabel:SetPoint("LEFT", pagePrev, "RIGHT", 3, 0)
pagePrev:SetScript("OnClick", function()
    detailPage = math.max(1, detailPage-1)
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
pageNext:SetScript("OnClick", function()
    detailPage = detailPage+1
    scroll:SetVerticalScroll(0)
    GetGear:RefreshUI()
end)
scroll = CreateFrame("ScrollFrame", nil, window, "UIPanelScrollFrameTemplate")
scroll:SetPoint("TOPLEFT", 17, -214)
scroll:SetPoint("BOTTOMRIGHT", -35, 15)
local content = CreateFrame("Frame", nil, scroll)
content:SetSize(720, 400)
scroll:SetScrollChild(content)

-- Detailed-window-only account inventory browser. It reads the existing
-- account snapshots and does not store state or modify character checklists.
local inventoryMode=false
local inventoryScope="eligible"
local inventorySearch=""
local inventorySelectedID=nil
local inventoryResults={}
local inventoryMeta={}
local inventoryChoices={}

local inventoryView=CreateFrame("Frame",nil,window)
inventoryView:SetAllPoints(window)
inventoryView:Hide()
local inventoryTitle=NewText(inventoryView,"GameFontNormalLarge",390)
inventoryTitle:SetPoint("TOPLEFT",18,-94)
inventoryTitle:SetText("ACCOUNT INVENTORY")
local inventoryBack=NewButton(inventoryView,"Return to guide",145,24)
inventoryBack:SetPoint("TOPRIGHT",-18,-90)
local inventoryScopeButton=NewButton(inventoryView,"Scope: Same realm/faction",300,25)
inventoryScopeButton:SetPoint("TOPLEFT",18,-130)
local inventorySearchLabel=NewText(inventoryView,"GameFontHighlightSmall",82)
inventorySearchLabel:SetPoint("LEFT",inventoryScopeButton,"RIGHT",12,0)
inventorySearchLabel:SetText("Find item:")
local inventorySearchBox=CreateFrame("EditBox",nil,inventoryView,"InputBoxTemplate")
inventorySearchBox:SetPoint("LEFT",inventorySearchLabel,"RIGHT",6,0)
inventorySearchBox:SetPoint("RIGHT",inventoryView,"RIGHT",-26,0)
inventorySearchBox:SetHeight(24)
inventorySearchBox:SetAutoFocus(false)
inventorySearchBox:SetMaxLetters(80)
local inventoryHelp=NewText(inventoryView,"GameFontHighlightSmall",730)
inventoryHelp:SetPoint("TOPLEFT",18,-166)
inventoryHelp:SetText("Last-known snapshots. Visit a character and open its bank to refresh counts.")
local inventoryStatus=NewText(inventoryView,"GameFontHighlightSmall",730)
inventoryStatus:SetPoint("TOPLEFT",18,-184)

local inventoryDetailPanel=CreateFrame("Frame",nil,inventoryView)
inventoryDetailPanel:SetWidth(254)
inventoryDetailPanel:SetPoint("TOPRIGHT",-18,-237)
inventoryDetailPanel:SetPoint("BOTTOMRIGHT",-18,20)
local inventoryPanelBackground=inventoryDetailPanel:CreateTexture(nil,"BACKGROUND")
inventoryPanelBackground:SetAllPoints()
inventoryPanelBackground:SetColorTexture(0.075,0.105,0.17,0.95)
-- The selected-character list uses the same stock scroll template as the
-- item list/overlay. Its scroll bar sits against the RIGHT edge of this blue
-- panel, so reserve a dark track for it rather than painting blue behind it.
local inventoryDetailScrollGutter=inventoryDetailPanel:CreateTexture(nil,"BORDER")
inventoryDetailScrollGutter:SetPoint("TOPRIGHT",inventoryDetailPanel,"TOPRIGHT",0,0)
inventoryDetailScrollGutter:SetPoint("BOTTOMRIGHT",inventoryDetailPanel,"BOTTOMRIGHT",0,0)
inventoryDetailScrollGutter:SetWidth(29)
inventoryDetailScrollGutter:SetColorTexture(0.025,0.035,0.055,0.98)
local selectedScroll=CreateFrame("ScrollFrame",nil,inventoryDetailPanel,"UIPanelScrollFrameTemplate")
selectedScroll:SetPoint("TOPLEFT",8,0)
selectedScroll:SetPoint("BOTTOMRIGHT",-27,0)
local selectedContent=CreateFrame("Frame",nil,selectedScroll)
selectedContent:SetSize(215,200)
selectedScroll:SetScrollChild(selectedContent)
-- Put selected-item summary within the scrollable content.
local selectedTitle=NewText(selectedContent,"GameFontNormal",200)
selectedTitle:SetPoint("TOPLEFT",2,-10)
local selectedTotals=NewText(selectedContent,"GameFontHighlightSmall",200)
selectedTotals:SetPoint("TOPLEFT",2,-32)
local selectedNote=NewText(selectedContent,"GameFontHighlightSmall",200)
selectedNote:SetPoint("TOPLEFT",2,-52)
selectedNote:SetTextColor(0.70,0.79,0.89)
local selectedRows={}

local inventoryListScroll=CreateFrame("ScrollFrame",nil,inventoryView,"UIPanelScrollFrameTemplate")
inventoryListScroll:SetPoint("TOPLEFT",18,-237)
-- UIPanelScrollFrameTemplate places its 16px scrollbar 6px OUTSIDE the
-- scroll frame. Reserve space for it plus a clear gutter to the right panel.
inventoryListScroll:SetPoint("BOTTOMRIGHT",inventoryDetailPanel,"BOTTOMLEFT",-38,0)
local inventoryListContent=CreateFrame("Frame",nil,inventoryListScroll)
inventoryListContent:SetSize(440,300)
inventoryListScroll:SetScrollChild(inventoryListContent)
local inventoryHeadItem=NewText(inventoryView,"GameFontNormalSmall",200)
inventoryHeadItem:SetPoint("BOTTOMLEFT",inventoryListScroll,"TOPLEFT",35,4)
inventoryHeadItem:SetText("ITEM")
local inventoryHeadBags=NewText(inventoryView,"GameFontNormalSmall",45,"RIGHT")
inventoryHeadBags:SetPoint("BOTTOMRIGHT",inventoryListScroll,"TOPRIGHT",-124,4)
inventoryHeadBags:SetText("BAGS")
local inventoryHeadBank=NewText(inventoryView,"GameFontNormalSmall",45,"RIGHT")
inventoryHeadBank:SetPoint("BOTTOMRIGHT",inventoryListScroll,"TOPRIGHT",-76,4)
inventoryHeadBank:SetText("BANK")
local inventoryHeadTotal=NewText(inventoryView,"GameFontNormalSmall",48,"RIGHT")
inventoryHeadTotal:SetPoint("BOTTOMRIGHT",inventoryListScroll,"TOPRIGHT",-27,4)
inventoryHeadTotal:SetText("TOTAL")
local inventoryEmpty=NewText(inventoryListContent,"GameFontHighlightSmall",380)
inventoryEmpty:SetPoint("TOPLEFT",13,-20)
local inventoryRowHeight=37
local inventoryRows={}
local RefreshInventoryBrowser,RefreshSelectedItem,RenderInventoryRows

local function InventoryScopeName(scope)
    if scope=="eligible" then return "Same realm/faction" end
    if scope=="current" then return "Current character" end
    if scope=="alts" then return "Eligible alts" end
    if scope=="other" then return "Other realms/factions" end
    if scope=="all" then return "All saved characters*" end
    for _,c in ipairs(inventoryChoices) do
        if scope==c.key then return c.name.." ("..c.realm..")" end
    end
    return "Same realm/faction"
end

local function InventoryRow(index)
    local row=CreateFrame("Button",nil,inventoryListContent)
    row:SetSize(445,inventoryRowHeight-1)
    local bg=row:CreateTexture(nil,"BACKGROUND")
    bg:SetAllPoints()
    row.bg=bg
    local icon=NewIcon(row,27)
    -- Let the entire row (including the icon) receive selection clicks.
    icon:EnableMouse(false)
    icon:SetPoint("LEFT",5,0)
    local name=NewText(row,"GameFontHighlightSmall",180)
    name:SetPoint("LEFT",icon,"RIGHT",8,0)
    local bags=NewText(row,"GameFontHighlightSmall",42,"RIGHT")
    bags:SetPoint("RIGHT",row,"RIGHT",-105,0)
    local bank=NewText(row,"GameFontHighlightSmall",42,"RIGHT")
    bank:SetPoint("RIGHT",row,"RIGHT",-57,0)
    local total=NewText(row,"GameFontNormalSmall",46,"RIGHT")
    total:SetPoint("RIGHT",row,"RIGHT",-8,0)
    row:SetScript("OnClick",function(self)
        inventorySelectedID=self.itemID
        RefreshSelectedItem()
        RenderInventoryRows()
    end)
    row:SetScript("OnEnter",function(self)
        if not self.itemID then return end
        self.bg:SetColorTexture(0.17,0.24,0.34,1)
        if GameTooltip then
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            if type(GameTooltip.SetItemByID)=="function" then
                GameTooltip:SetItemByID(self.itemID)
            else
                GameTooltip:SetHyperlink("item:"..tostring(self.itemID))
            end
            GameTooltip:AddLine("Click for saved character locations",0.67,0.84,1)
            GameTooltip:Show()
        end
    end)
    row:SetScript("OnLeave",function(self)
        HideItemTooltip()
        if self.itemID==inventorySelectedID then
            self.bg:SetColorTexture(0.14,0.21,0.31,1)
        else
            self.bg:SetColorTexture(0.08,0.12,0.19,self.rowNumber%2==0 and 0.95 or 0.76)
        end
    end)
    inventoryRows[index]={frame=row,icon=icon,name=name,bags=bags,bank=bank,total=total}
end
for i=1,32 do InventoryRow(i) end

local function InventoryTimestamp(at)
    return GetGear.AltInventory and GetGear.AltInventory:FormatScanTime(at) or "never"
end

RefreshSelectedItem=function()
    local item=nil
    for _,entry in ipairs(inventoryResults) do
        if entry.itemID==inventorySelectedID then item=entry;break end
    end
    for _,entry in ipairs(selectedRows) do entry:Hide() end
    if not item then
        selectedTitle:SetText("Select an item")
        selectedTotals:SetText("Click an item on the left")
        selectedNote:SetText("See exactly which character holds it")
        selectedContent:SetHeight(90)
        return
    end
    selectedTitle:SetText(item.name)
    local incomplete=inventoryMeta.missingBanks>0 or inventoryMeta.missingBags>0 or inventoryMeta.partialBanks>0
    selectedTotals:SetText("Bags "..item.bags.."  |  Bank "..item.bank.."  |  Known total "..item.total)
    selectedNote:SetText(incomplete and "Some snapshots missing: totals are minimums." or "Last-known quantities, not live transfers.")
    for i,loc in ipairs(item.locations) do
        local row=selectedRows[i]
        if not row then
            row=CreateFrame("Frame",nil,selectedContent)
            row:SetWidth(213)
            local title=NewText(row,"GameFontNormalSmall",208)
            title:SetPoint("TOPLEFT",2,-2)
            local counts=NewText(row,"GameFontHighlightSmall",208)
            counts:SetPoint("TOPLEFT",2,-20)
            local ages=NewText(row,"GameFontHighlightSmall",208)
            ages:SetPoint("TOPLEFT",2,-38)
            row.title=title;row.counts=counts;row.ages=ages
            selectedRows[i]=row
        end
        row:SetHeight(60)
        row:ClearAllPoints()
        row:SetPoint("TOPLEFT",selectedContent,"TOPLEFT",0,-90-(i-1)*60)
        row.title:SetText(loc.name..(loc.eligible and "" or " |cffffb366(other realm/faction)|r"))
        row.counts:SetText("Bags "..loc.bags.."  |  Bank "..(loc.bankKnown and tostring(loc.bank) or "?") )
        row.ages:SetText("Bag "..InventoryTimestamp(loc.bagsAt).."; Bank "..InventoryTimestamp(loc.bankAt))
        row:Show()
    end
    selectedContent:SetHeight(math.max(90,90+#item.locations*60))
end

RenderInventoryRows=function()
    local width=math.max(330,(inventoryListScroll:GetWidth() or 440)-19)
    inventoryListContent:SetWidth(width)
    local offset=math.max(0,math.floor((inventoryListScroll:GetVerticalScroll() or 0)/inventoryRowHeight))
    for i,row in ipairs(inventoryRows) do
        local index=offset+i
        local entry=inventoryResults[index]
        if entry then
            row.frame:ClearAllPoints()
            row.frame:SetPoint("TOPLEFT",inventoryListContent,"TOPLEFT",0,-(index-1)*inventoryRowHeight)
            row.frame:SetWidth(width)
            row.name:SetWidth(math.max(80,width-202))
            row.rowNumber=index
            row.frame.rowNumber=index
            row.frame.itemID=entry.itemID
            SetItemIcon(row.icon,entry.itemID)
            row.name:SetText(entry.name)
            row.bags:SetText(tostring(entry.bags)..(inventoryMeta.missingBags>0 and "+" or ""))
            row.bank:SetText(tostring(entry.bank)..((inventoryMeta.missingBanks>0 or inventoryMeta.partialBanks>0) and "+" or ""))
            row.total:SetText(tostring(entry.total)..((inventoryMeta.missingBags>0 or inventoryMeta.missingBanks>0 or inventoryMeta.partialBanks>0) and "+" or ""))
            if entry.itemID==inventorySelectedID then
                row.frame.bg:SetColorTexture(0.14,0.21,0.31,1)
            else
                row.frame.bg:SetColorTexture(0.08,0.12,0.19,index%2==0 and 0.95 or 0.76)
            end
            row.frame:Show()
        else
            row.frame:Hide()
            row.frame.itemID=nil
        end
    end
    inventoryEmpty:SetWidth(width-25)
    if #inventoryResults==0 then
        inventoryEmpty:SetText(inventorySearch~="" and "No matching items. Try another search." or
            "No saved items in this scope. Log onto a character, then open its bank to scan.")
        inventoryEmpty:Show()
    else inventoryEmpty:Hide() end
end

RefreshInventoryBrowser=function(resetScroll)
    if not inventoryMode then return end
    if not (GetGear.AltInventory and GetGear.AltInventory.BrowseItems) then return end
    inventoryChoices=GetGear.AltInventory:BrowserCharacters()
    inventoryResults,inventoryMeta=GetGear.AltInventory:BrowseItems(inventoryScope,inventorySearch)
    inventoryScopeButton:SetText("Scope: "..InventoryScopeName(inventoryScope))
    inventoryStatus:SetText(#inventoryResults.." items  |  "..#inventoryMeta.characters.." character(s)  |  "
        ..inventoryMeta.missingBanks.." bank(s) unscanned"
        ..(inventoryMeta.missingBags>0 and ("  |  "..inventoryMeta.missingBags.." bag(s) unscanned") or "")
        ..(inventoryMeta.partialBanks>0 and ("  |  "..inventoryMeta.partialBanks.." partial bank(s)") or ""))
    inventoryHelp:SetText(inventoryScope=="all" and
        "*Different realms/factions are combined for browsing only; transfers are not guaranteed."
        or "Click an item for locations and scan dates. A + means some inventories are unscanned.")
    if resetScroll then inventoryListScroll:SetVerticalScroll(0) end
    inventoryListContent:SetHeight(math.max(50,#inventoryResults*inventoryRowHeight))
    local present=false
    for _,entry in ipairs(inventoryResults) do
        if entry.itemID==inventorySelectedID then present=true;break end
    end
    if not present then inventorySelectedID=inventoryResults[1] and inventoryResults[1].itemID or nil end
    RenderInventoryRows()
    RefreshSelectedItem()
end

inventoryListScroll:HookScript("OnVerticalScroll",function() RenderInventoryRows() end)
inventorySearchBox:SetScript("OnTextChanged",function(self)
    inventorySearch=self:GetText() or ""
    RefreshInventoryBrowser(true)
end)
inventorySearchBox:SetScript("OnEscapePressed",function(self) self:ClearFocus() end)
inventorySearchBox:SetScript("OnEnterPressed",function(self) self:ClearFocus() end)
inventoryScopeButton:SetScript("OnClick",function()
    local order={"eligible","current","alts","other","all"}
    for _,c in ipairs(inventoryChoices) do order[#order+1]=c.key end
    local index=1
    for i,key in ipairs(order) do if key==inventoryScope then index=i;break end end
    inventoryScope=order[(index%#order)+1]
    RefreshInventoryBrowser(true)
end)
inventoryScopeButton:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Inventory scope",1,0.84,0.42)
    GameTooltip:AddLine("Click to cycle current character, eligible alts, other characters, and individual saved characters.",1,1,1,true)
    GameTooltip:AddLine("Combined transferable totals use same-realm/faction only; all-character mode is for reference.",0.78,0.84,0.91,true)
    GameTooltip:Show()
end)
inventoryScopeButton:SetScript("OnLeave",HideItemTooltip)
inventoryBack:SetScript("OnClick",function()
    inventoryMode=false
    GetGear:RefreshUI()
end)
function GetGear:ShowAltInventoryBrowser()
    if not self.db then return end
    preview.active=false
    inventoryMode=true
    inventoryScope="eligible"
    inventorySearch=""
    inventorySelectedID=nil
    inventorySearchBox:SetText("")
    self:RefreshUI()
end

local detailRows = {}
local wishlistUI = {starPresentationOnly=false,detailStarModel={},overlayStarModel={}}
function wishlistUI.RememberStars(list)
    local records={}
    for _,gear in ipairs(list) do
        if GetGear:IsItemStarred(gear.itemID) then records[gear.itemID]=gear end
    end
    return records
end
-- Keep the pool dense even when a newly visible item has no reusable row.
-- Reuse expensive row bodies by ID, then bind every frame to its sorted position.
function wishlistUI.ReusePresentationRows(rows,list,create)
    local byID,used,ordered={},{},{}
    for _,row in ipairs(rows) do
        -- Hidden bodies may predate a resize, filter or page change. Reuse only
        -- the current visible presentation; entering rows must measure afresh.
        if not (row.f or row.frame):IsShown() then row.gear=nil end
        if row.gear then byID[row.gear.itemID]=row end
    end
    for i,gear in ipairs(list) do
        local row=byID[gear.itemID]
        if row then ordered[i]=row;used[row]=true end
    end
    local free={}
    for _,row in ipairs(rows) do if not used[row] then free[#free+1]=row end end
    for i=1,#list do if not ordered[i] then ordered[i]=table.remove(free) or create(i) end end
    -- Every displayed position now owns a frame; unused frames remain pooled.
    for i=1,#list do rows[i]=ordered[i] end
    for i=#list+1,#list+#free do rows[i]=table.remove(free) end
end
function wishlistUI.CountStars(list)
    local count=0
    for _,gear in ipairs(list) do if GetGear:IsItemStarred(gear.itemID) then count=count+1 end end
    return count
end
function wishlistUI.LayoutActions(parent,buttons)
    local right=7
    for _,button in ipairs(buttons) do
        if button:IsShown() then
            button:ClearAllPoints()
            button:SetPoint("TOPRIGHT",parent,"TOPRIGHT",-right,-5)
            right=right+button:GetWidth()+5
        end
    end
end
function wishlistUI.CommitScrollLayout(scrollFrame)
    -- Native ScrollFrames cache their child rectangle. A star reorder can keep
    -- identical dimensions; explicitly commit changed child positions as well.
    if scrollFrame.UpdateScrollChildRect then scrollFrame:UpdateScrollChildRect() end
end
function wishlistUI.NewStarButton(parent)
    local button=CreateFrame("Button",nil,parent)
    button:SetSize(22,22)
    button:RegisterForClicks("LeftButtonUp")
    button.starTexture=button:CreateTexture(nil,"ARTWORK")
    button.starTexture:SetAllPoints()
    button:SetHighlightTexture("Interface\\Buttons\\ButtonHilight-Square","ADD")
    button:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine(self.preview and "Preview is read-only" or "Star / unstar for this character",1,0.82,0.35)
        GameTooltip:Show()
    end)
    button:SetScript("OnLeave",HideItemTooltip)
    button:SetScript("OnClick",function(self)
        if not self.record then return end
        local ok,reason=GetGear:SetItemStarred(self.record.itemID,
            not GetGear:IsItemStarred(self.record.itemID),self.preview)
        if not ok and GetGear.Say then GetGear.Say(reason) end
    end)
    return button
end
function wishlistUI.AssignStar(button,gear,inPreview)
    button.record,button.preview=gear,inPreview
    button.starred=GetGear:IsItemStarred(gear.itemID)
    button.starTexture:SetTexture(button.starred and "Interface\\AddOns\\GetGear\\StarFilled.tga"
        or "Interface\\AddOns\\GetGear\\StarOutline.tga")
    button:SetEnabled(not inPreview)
    button:SetShown(not gear.bagUpgrade)
end
function wishlistUI.GroupLabel(parent)
    local label=NewText(parent,"GameFontNormalSmall",280)
    label:Hide()
    return label
end
wishlistUI.detailGroups={wishlistUI.GroupLabel(content),wishlistUI.GroupLabel(content)}
local function NewDetailRow(i)
    local frame = CreateFrame("Frame", nil, content)
    frame:SetSize(717, 160)
    local bg = frame:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    bg:SetColorTexture(0.07, 0.10, 0.16, i % 2 == 0 and 0.76 or 0.92)
    local item = NewIcon(frame, 41)
    item:SetPoint("TOPLEFT", 10, -13)
    local name = NewText(frame, "GameFontNormal", 492)
    name:SetPoint("TOPLEFT", 62, -12)
    local meta = NewText(frame, "GameFontHighlightSmall", 510)
    meta:SetPoint("TOPLEFT", 62, -34)

    local levelHeader = NewText(frame, "GameFontHighlightSmall", 55, "CENTER")
    levelHeader:SetPoint("TOPRIGHT", -12, -11)
    levelHeader:SetText("LEVEL")
    local levelValue = NewText(frame, "GameFontNormal", 55, "CENTER")
    levelValue:SetPoint("TOP", levelHeader, "BOTTOM", 0, -3)

    local metaSourceIcon = NewProfessionIcon(frame, 18)
    local metaRest = NewText(frame, "GameFontHighlightSmall", 390)
    local professionIcon = NewProfessionIcon(frame,18)
    local profession = NewText(frame, "GameFontHighlightSmall", 150)
    local desc = NewText(frame, "GameFontHighlightSmall", 636)
    local benefits = {}
    local comparison = NewText(frame, "GameFontHighlightSmall", 625)
    local matTitle = NewText(frame, "GameFontNormalSmall", 550)
    matTitle:SetText("MATERIALS")
    local materials = {}
    local action1 = NewButton(frame, "Acquired", 108)
    local action2 = NewButton(frame, "Skip", 90)
    local action3 = NewButton(frame, "Hide", 90)
    local pin = NewAcquisitionPin(frame, 24)
    local star=wishlistUI.NewStarButton(frame)
    star:SetPoint("TOPRIGHT",-76,-10)
    detailRows[i] = {frame=frame, item=item, name=name, meta=meta,
        levelHeader=levelHeader,levelValue=levelValue,
        metaSourceIcon=metaSourceIcon,metaRest=metaRest,
        profession=profession,professionIcon=professionIcon, desc=desc,
        benefits=benefits, comparison=comparison, matTitle=matTitle, mats=materials,
        a=action1, b=action2, c=action3, pin=pin, star=star}
    return detailRows[i]
end

local function RefreshUI(self)
    if not self.db then return end
    if inventoryMode then
        levelText:SetText("GetGear  |  Account inventory")
        subtitle:SetText("Search saved bags and banks across your characters. Offline counts are last known, not live.")
        for _,button in ipairs(tabs) do button:Hide() end
         startPreview:Hide(); altInventoryButton:Hide();optionsButton:Hide()
        previewHeading:Hide();exitPreview:Hide()
        previewClassButton:Hide();
        previewMinus:Hide();previewPlus:Hide();previewLevelLabel:Hide();previewLevel:Hide();previewFullButton:Hide()
        statusText:Hide()
        detailContext:Hide()
        detailSlot:Hide()
        pagePrev:Hide(); pageNext:Hide(); pageLabel:Hide()
        scroll:Hide()
        inventoryView:Show()
        RefreshInventoryBrowser()
        return
    end
    inventoryView:Hide()
    scroll:Show();statusText:Show();optionsButton:Show();detailContext:Show()
    detailSlot:Update()
    local inPreview = preview.active
    PositionDisplaySettingsForPreview(inPreview)
    local playerName = UnitName("player") or "Character"
    local race = type(UnitRace)=="function" and UnitRace("player") or ""
    local class = self.className or (type(UnitClass)=="function" and UnitClass("player")) or "Class"
    local classToken = type(UnitClass)=="function" and select(2,UnitClass("player")) or nil
    local list
    for _, button in ipairs(tabs) do
        if inPreview then button:Hide() else button:Show() end
    end
    if inPreview then
        list = PreviewEntries()
        levelText:SetText("GetGear  |  " .. ColoredCharacterLabel(
            preview.full and "1-60" or preview.level, "", previewNames[preview.classToken], preview.classToken))
        subtitle:SetText("Browse future or alternate-class gear. Read-only: no saves, equip comparisons or live status filters.")
        startPreview:Hide();  altInventoryButton:Hide()
        previewHeading:Show(); exitPreview:Show()
        previewClassButton:Show(); 
        previewMinus:Show(); previewPlus:Show(); previewLevelLabel:Show(); previewLevel:Show(); previewFullButton:Show()
        previewClassButton:SetText("Class: " .. previewNames[preview.classToken])
        previewLevel:SetText(tostring(preview.level))
        previewFullButton:SetText(preview.full and "Full 1-60: ON" or "Full 1-60: OFF")
        detailContext:SetText(preview.full and "Preview: all levels" or ("Preview: up to level "..preview.level))
        scroll:ClearAllPoints()
        scroll:SetPoint("TOPLEFT",17,-214)
        scroll:SetPoint("BOTTOMRIGHT",-35,15)
    else
        list = wishlistUI.starPresentationOnly and wishlistUI.detailModel or self:GetItems(self.activeTab)
        wishlistUI.detailModel=list
        if self.ComposeStarredItems then list=self:ComposeStarredItems(list,self.activeTab,wishlistUI.starPresentationOnly and wishlistUI.detailStarModel or nil,true);wishlistUI.detailStarModel=wishlistUI.RememberStars(list) end
        levelText:SetText(playerName .. "  |  " .. ColoredCharacterLabel(self.level, race, class, classToken))
        subtitle:SetText("Hover for stats. Equipped gear appears in Completed; outclassed and older imported gear in Earlier Gear. Saves unchanged.")
         startPreview:Show(); altInventoryButton:Show()
        previewHeading:Hide(); exitPreview:Hide()
        previewClassButton:Hide(); 
        previewMinus:Hide(); previewPlus:Hide(); previewLevelLabel:Hide(); previewLevel:Hide(); previewFullButton:Hide()
        local dominant=self.GetDominantTalentTree and self:GetDominantTalentTree()
        detailContext:SetText(dominant and (dominant.." talents") or "")
        scroll:ClearAllPoints()
        scroll:SetPoint("TOPLEFT",17,-214)
        scroll:SetPoint("BOTTOMRIGHT",-35,15)
    end
    -- The dedicated Bags view keeps its existing planning behaviour. Hidden
    -- and tracker lists may contain bags and can still select the Bags group.
    local dedicatedBags = not inPreview and self.activeTab=="bags"
    if dedicatedBags then detailSlot:Hide() else detailSlot:Show() end
    local slot = dedicatedBags and "all" or self:GetEquipmentSlotFilter("detail")
    local total
    list, total = self:FilterEquipmentSlots(list, slot)
    local matches = #list
    local starredCount=wishlistUI.CountStars(list)
    local relevanceKey = self.db.overlay.showAllValidGear and "all" or "relevant"
    local viewKey = inPreview and ("preview:"..preview.classToken..":"..
        tostring(preview.level)..":"..tostring(preview.full)..":"..relevanceKey)
        or ("character:"..tostring(self.activeTab)..":"..tostring(self.level)..":"..relevanceKey..":"..tostring(self.dominantTalentTree))
    if detailViewKey ~= viewKey then
        detailPage, detailViewKey = 1, viewKey
        scroll:SetVerticalScroll(0)
    end
    -- Keep the current page/scroll when possible; clamp only if the new
    -- filtered list is shorter. Filters never affect the unfiltered view key.
    local pageCount = math.max(1, math.ceil(#list/DETAIL_PAGE_SIZE))
    if detailPage>pageCount then
        detailPage=pageCount
        scroll:SetVerticalScroll(0)
    end
    if pageCount > 1 then
        pagePrev:Show(); pageNext:Show(); pageLabel:Show()
        pagePrev:SetEnabled(detailPage>1)
        pageNext:SetEnabled(detailPage<pageCount)
        pageLabel:SetText(detailPage.."/"..pageCount)
        local subset = {}
        local first = (detailPage-1)*DETAIL_PAGE_SIZE+1
        for i=first, math.min(#list, first+DETAIL_PAGE_SIZE-1) do
            subset[#subset+1] = list[i]
        end
        list = subset
    else
        pagePrev:Hide(); pageNext:Hide(); pageLabel:Hide()
    end
    statusText:SetText(self:EquipmentSlotCountText(matches, total, #list))
    local innerWidth = math.max(655, (scroll:GetWidth() or 725) - 5)
    content:SetWidth(innerWidth)
    if wishlistUI.starPresentationOnly then wishlistUI.ReusePresentationRows(detailRows,list,NewDetailRow) end
    local y = 0
    for _,label in ipairs(wishlistUI.detailGroups) do label:Hide() end
    local lastGroup,groupIndex=nil,0
    if #list == 0 then
        local row = detailRows[1] or NewDetailRow(1)
        row.frame:ClearAllPoints()
        row.frame:SetWidth(innerWidth-3)
        row.frame:SetPoint("TOPLEFT", content, "TOPLEFT", 0, 0)
        row.frame:SetHeight(95)
        row.gear=nil -- Empty-state labels are not a reusable rendered item body.
        row.name:ClearAllPoints();row.name:SetPoint("TOPLEFT",12,-12)
        row.name:SetWidth(innerWidth-30)
        row.meta:ClearAllPoints();row.meta:SetPoint("TOPLEFT",12,-40)
        row.meta:SetWidth(innerWidth-30)
        row.item:Hide()
        row.name:SetText(slot~="all" and "No recommendations for this slot." or "No gear objectives in this category")
        row.meta:SetText(slot~="all" and "Choose All Slots or another slot to review this view."
            or inPreview and "No equipment for this class and level; try Full 1-60."
            or (#self.Gear == 0 and self:GetGuideEmptyMessage()
            or (self.activeTab=="bags" and "No ordinary bag upgrades needed, bag inspection unavailable, or bag recommendations disabled."
            or self.activeTab=="earlier" and "No gear is outclassed or at least five levels below you in the default imported guide."
            or "Check other tabs; manually hidden equipment remains in Hidden.")))
        row.levelHeader:SetText("LEVEL")
        row.levelValue:SetText("")
        row.desc:Hide()
        row.comparison:Hide()
        row.profession:Hide();row.professionIcon:Hide()
        row.metaSourceIcon:Hide();row.metaRest:Hide()
        row.matTitle:Hide()
        row.a:Hide(); row.b:Hide(); row.c:Hide(); row.pin:Hide(); row.star:Hide()
        for _, w in ipairs(row.benefits) do w:Hide() end
        for _, w in ipairs(row.mats) do w.frame:Hide() end
        row.frame:Show()
        y = 102
    else
        for i, gear in ipairs(list) do
            local group=not inPreview and self.IsItemStarred and self:IsItemStarred(gear.itemID) and "Starred Items" or "Other Recommendations"
            if not inPreview and self.db.starredItems and next(self.db.starredItems) and group~=lastGroup then
                groupIndex=groupIndex+1
                local label=wishlistUI.detailGroups[groupIndex]
                label:ClearAllPoints();label:SetPoint("TOPLEFT",content,"TOPLEFT",10,-y)
                label:SetText(group=="Starred Items" and (group.." ("..starredCount..")") or group);label:Show();y=y+23;lastGroup=group
            end
            local row = detailRows[i] or NewDetailRow(i)
            row.frame:ClearAllPoints()
            row.frame:SetPoint("TOPLEFT", content, "TOPLEFT", 0, -y)
            row.frame:SetWidth(innerWidth-3)
            row.frame:Show()
            wishlistUI.AssignStar(row.star,gear,inPreview)
            if wishlistUI.starPresentationOnly and row.gear and row.gear.itemID==gear.itemID then
                row.levelHeader:SetText(gear.bagUpgrade and "SLOTS" or
                    (self:IsItemStarred(gear.itemID) and gear.targetLevel>(self.level or 1) and "FUTURE" or "LEVEL"))
                row.frame:Show();y=y+row.frame:GetHeight()+11
            else
            if not inPreview and self:IsItemStarred(gear.itemID) then gear=self:GetRecommendationRecord(gear) end
            row.gear=gear
            row.item:ClearAllPoints();row.item:SetPoint("TOPLEFT",10,-39)
            row.name:ClearAllPoints();row.name:SetPoint("TOPLEFT",62,-39)
            row.name:SetWidth(innerWidth-85)
            row.desc:SetWidth(innerWidth-85)
            row.item:Show()
            SetItemIcon(row.item, gear.itemID,nil,nil,gear,inPreview)
            row.name:SetText(gear.name .. (gear.bagUpgrade and ("  x"..gear.quantity) or "") .. (not inPreview and self.activeTab=="completed" and self:GetStatus(gear)==nil
                and self:IsGearEquipped(gear) and "  |cff66e29b(Equipped)|r" or ""))
            local sourceProf=ProfessionSource(gear)
            if sourceProf then
                row.meta:SetText((gear.slot or "Item") .. "  |")
                row.meta:SetWidth(math.ceil(row.meta:GetStringWidth() or 58)+2)
                row.metaSourceIcon:ClearAllPoints()
                row.metaSourceIcon:SetPoint("LEFT",row.meta,"RIGHT",8,0)
                SetProfessionIcon(row.metaSourceIcon,sourceProf)
                row.metaRest:ClearAllPoints()
                row.metaRest:SetPoint("LEFT",row.metaSourceIcon,"RIGHT",5,0)
                row.metaRest:SetText("|  " .. (gear.zone or "Unknown"))
                row.metaRest:Show()
            else
                row.meta:SetWidth(innerWidth-85)
                row.meta:SetText((gear.slot or "Item") .. "  |  " .. (gear.sourceType or "Source") .. "  |  " .. (gear.zone or "Unknown"))
                row.metaSourceIcon:Hide();row.metaRest:Hide()
            end
            row.levelHeader:SetText(gear.bagUpgrade and "SLOTS" or "LEVEL")
            row.levelValue:SetText(gear.bagUpgrade and tostring(gear.bagSlots) or tostring(gear.targetLevel))
            if not inPreview and self:IsItemStarred(gear.itemID) and gear.targetLevel>(self.level or 1) then
                row.levelHeader:SetText("FUTURE")
            end

            local metaY=39+MeasureText(row.name,14)+8
            row.meta:ClearAllPoints();row.meta:SetPoint("TOPLEFT",62,-metaY)
            row.metaRest:SetWidth(math.max(80,innerWidth-110-row.meta:GetWidth()))
            if sourceProf then
                row.metaSourceIcon:ClearAllPoints()
                row.metaSourceIcon:SetPoint("TOPLEFT",row.frame,"TOPLEFT",70+row.meta:GetWidth(),-metaY)
                row.metaRest:ClearAllPoints()
                row.metaRest:SetPoint("TOPLEFT",row.frame,"TOPLEFT",93+row.meta:GetWidth(),-metaY)
            end
            local nextY=metaY+math.max(MeasureText(row.meta,14),sourceProf and MeasureText(row.metaRest,18) or 0)+8
            row.levelHeader:ClearAllPoints();row.levelHeader:SetPoint("TOPLEFT",62,-nextY)
            row.levelValue:ClearAllPoints();row.levelValue:SetPoint("TOPLEFT",124,-nextY)
            nextY=nextY+math.max(MeasureText(row.levelHeader,14),MeasureText(row.levelValue,14))+8
            if UpdateProfessionSkill(row.professionIcon,row.profession,gear,nil,inPreview) then
                row.professionIcon:ClearAllPoints()
                row.professionIcon:SetPoint("TOPLEFT",row.frame,"TOPLEFT",62,-nextY)
                row.profession:ClearAllPoints()
                if row.professionIcon:IsShown() then
                    row.profession:SetPoint("LEFT",row.professionIcon,"RIGHT",7,0)
                else
                    row.profession:SetPoint("TOPLEFT",row.frame,"TOPLEFT",62,-nextY)
                end
                nextY=nextY+math.max(18,MeasureText(row.profession,14))+8
            end
            -- Automatic comparison: visible in every item row, no extra toggle.
            local changeText,showChange = "",false
            if not inPreview and not gear.bagUpgrade then changeText,showChange=self:ComparisonInline(gear,true) end
            if showChange and changeText ~= "" then
                row.comparison:ClearAllPoints()
                row.comparison:SetPoint("TOPLEFT",row.frame,"TOPLEFT",62,-nextY)
                row.comparison:SetWidth(innerWidth-88)
                row.comparison:SetText(changeText)
                row.comparison:Show()
                nextY=nextY+MeasureText(row.comparison,28)+8
            else
                row.comparison:Hide()
            end
            -- The colored gear-stat deltas above replace the older fixed
            -- +damage/+healing/+attribute badge rows. Item tooltips remain
            -- available for full stats, including wand DPS and special effects.
            for _, widget in ipairs(row.benefits) do widget:Hide() end

            row.desc:ClearAllPoints()
            row.desc:SetPoint("TOPLEFT", row.frame, "TOPLEFT", 62, -nextY)
            local restriction=not inPreview and self:IsItemStarred(gear.itemID) and self:GetSearchRestriction(gear,true)
            row.desc:SetText((restriction and ("Unavailable: "..restriction.."\n") or "")..Describe(gear,inPreview))
            row.desc:Show()
            nextY = nextY + MeasureText(row.desc, 33) + 14

            local reagents = self:GetCraftingMaterialRows(gear, inPreview)
            if #reagents>0 then
                row.matTitle:ClearAllPoints()
                row.matTitle:SetPoint("TOPLEFT", row.frame, "TOPLEFT", 62, -nextY)
                row.matTitle:SetText("MATERIALS")
                row.matTitle:Show()
                nextY = nextY + 19
                for j, mat in ipairs(reagents) do
                    local widget = row.mats[j]
                    if not widget then widget=NewReagent(row.frame, false); row.mats[j]=widget end
                    -- One per line so intermediate children remain directly below parents.
                    UpdateReagent(widget, mat, 62 + math.min(mat.depth or 0, 2)*20,
                        nextY+(j-1)*35, row.frame, false, inPreview)
                end
                nextY = nextY + #reagents*35 + 8
            else
                if self.IsCraftMaterialsUnknown and self:IsCraftMaterialsUnknown(gear) then
                    row.matTitle:ClearAllPoints()
                    row.matTitle:SetPoint("TOPLEFT", row.frame, "TOPLEFT", 62, -nextY)
                    row.matTitle:SetText("Materials not yet documented (not zero)")
                    row.matTitle:Show()
                    nextY = nextY + 19
                else
                    row.matTitle:Hide()
                end
            end
            for j=#reagents+1,#row.mats do row.mats[j].frame:Hide() end

            row.a:ClearAllPoints()
            row.a:SetPoint("TOPLEFT", row.frame, "TOPLEFT", 62, -nextY)
            row.b:ClearAllPoints()
            row.b:SetPoint("LEFT", row.a, "RIGHT", 7, 0)
            row.c:ClearAllPoints()
            row.c:SetPoint("LEFT", row.b, "RIGHT", 7, 0)
            row.pin:ClearAllPoints()
            row.pin:SetPoint("LEFT",row.c,"RIGHT",10,0)
            AssignAcquisitionPin(row.pin, gear)
            if restriction then row.pin:Hide() end
            if inPreview then
                row.a:Hide(); row.b:Hide(); row.c:Hide()
                row.a:SetScript("OnClick", nil)
                row.b:SetScript("OnClick", nil)
                row.c:SetScript("OnClick", nil)
                -- A map pin may still navigate to a source; it does not
                -- change player acquisition, hidden or skipped state.
                row.pin:ClearAllPoints()
                row.pin:SetPoint("TOPLEFT",row.frame,"TOPLEFT",62,-nextY)
            else
                local status = self:GetStatus(gear)
                if self.activeTab == "hidden" then
                    row.a:SetText("Restore")
                    row.a:SetScript("OnClick", function() self:SetHidden(gear, false) end)
                    row.b:SetText("Acquired")
                    row.b:SetScript("OnClick", function() self:SetStatus(gear, "acquired") end)
                    row.c:SetText("Skip")
                    row.c:SetScript("OnClick", function() self:SetStatus(gear, "skipped") end)
                    row.c:Show()
                elseif self.activeTab == "completed" then
                    row.a:SetText(status == "acquired" and "Undo acquire" or "Acquired")
                    row.a:SetScript("OnClick", function()
                        if status == "acquired" then
                            self:SetStatus(gear, nil)
                        else
                            self:SetStatus(gear, "acquired")
                        end
                    end)
                    row.b:SetText(status == "skipped" and "Undo skip" or "Skip")
                    row.b:SetScript("OnClick", function()
                        if status == "skipped" then
                            self:SetStatus(gear, nil)
                        else
                            self:SetStatus(gear, "skipped")
                        end
                    end)
                    row.c:Hide()
                else
                    row.a:SetText("Acquired")
                    row.a:SetScript("OnClick", function() self:SetStatus(gear, "acquired") end)
                    row.b:SetText("Skip")
                    row.b:SetScript("OnClick", function() self:SetStatus(gear, "skipped") end)
                    row.c:SetText("Hide")
                    row.c:SetScript("OnClick", function() self:SetHidden(gear, true) end)
                    row.c:Show()
                end
                row.a:Show(); row.b:Show()
                if gear.bagUpgrade then
                    -- Dynamic bag objectives can be hidden/restored, but can't be
                    -- manually Acquired or Skipped: worn slot counts own completion.
                    if self.activeTab == "hidden" then
                        row.a:Show(); row.b:Hide(); row.c:Hide()
                    else
                        row.a:Hide(); row.b:Hide(); row.c:Show()
                        row.c:ClearAllPoints()
                        row.c:SetPoint("TOPLEFT",row.frame,"TOPLEFT",62,-nextY)
                        row.c:SetScript("OnClick",function() self:SetHidden(gear,true) end)
                    end
                end
                if self.activeTab=="completed" then
                    row.pin:ClearAllPoints()
                    row.pin:SetPoint("LEFT",row.b,"RIGHT",10,0)
                end
            end
            wishlistUI.LayoutActions(row.frame,{row.c,row.b,row.a,row.pin,row.star})
            row.frame:SetHeight(nextY + 10)
            row.frame:Show()
            y = y + row.frame:GetHeight() + 11
            end -- reuse rendered row on a star click
        end
    end
    for i=(#list==0 and 2 or #list+1),#detailRows do detailRows[i].frame:Hide() end
    content:SetHeight(math.max(425,y))
    wishlistUI.CommitScrollLayout(scroll)
    local maxScroll = math.max(0, content:GetHeight()-scroll:GetHeight())
    if scroll:GetVerticalScroll()>maxScroll then scroll:SetVerticalScroll(maxScroll) end
end

function GetGear:RefreshUI()
    if self.WithRecommendationSnapshot then return self:WithRecommendationSnapshot(RefreshUI) end
    return RefreshUI(self)
end

AllowResizing(window,720,400,1260,1000)
function window:afterResize()
    if GetGear.db then
        GetGear.db.detail.width, GetGear.db.detail.height = math.floor(self:GetWidth()+0.5), math.floor(self:GetHeight()+0.5)
        GetGear.db.detail.x, GetGear.db.detail.y = self:GetLeft(),self:GetTop()
    end
    GetGear:RefreshUI()
end
window:SetScript("OnHide", function()
    StopTitleDrag()
    if window.isSizing then
        window:StopMovingOrSizing()
        window.isSizing=false
    end
    preview.active=false
    inventoryMode=false
end)
function GetGear:IsUIShown() return window:IsShown() end
function GetGear:ShowUI()
    window:Show()
    -- Keep this action idempotent: a Guide button should open/raise the guide,
    -- not close it when it is already visible.
    if type(window.Raise)=="function" then window:Raise() end
    self:RefreshUI()
end
function GetGear:ToggleUI()
    if window:IsShown() then window:Hide() else self:ShowUI() end
end

-- =====================================================================
-- Always-on tracker overlay: level-aware objectives + combined materials.
-- =====================================================================
local overlay = CreateFrame("Frame", "GetGear_TrackerOverlay", UIParent)
overlay:SetSize(354, 420)
overlay:SetPoint("TOPRIGHT", UIParent, "TOPRIGHT", -45, -135)
overlay:SetFrameStrata("MEDIUM")
overlay:SetMovable(true)
overlay:EnableMouse(true)
if overlay.SetClampedToScreen then overlay:SetClampedToScreen(true) end
overlay:Hide()

local background = overlay:CreateTexture(nil, "BACKGROUND")
background:SetAllPoints()

-- The draggable header must NOT overlap Guide or the character label.
-- In v0.7.1 it covered almost the entire header and could swallow clicks.
local dragArea = CreateFrame("Button", nil, overlay)
dragArea:SetPoint("TOPLEFT", 0, 0)
dragArea:SetSize(82, 32)
dragArea:RegisterForDrag("LeftButton")
dragArea:SetScript("OnDragStart", function()
    if GetGear.db and not GetGear.db.overlay.locked then overlay:StartMoving() end
end)
dragArea:SetScript("OnDragStop", function()
    overlay:StopMovingOrSizing()
    if GetGear.db then
        GetGear.db.overlay.x = overlay:GetLeft()
        GetGear.db.overlay.y = overlay:GetTop()
    end
end)
local trackerTitle = NewText(overlay, "GameFontNormal")
trackerTitle:SetPoint("TOPLEFT", 11, -10)
trackerTitle:SetText("GETGEAR")
-- Quick access to the full guide without typing a slash command.
local openGuide=NewButton(overlay,"Guide",52,22)
openGuide:SetPoint("TOPLEFT",overlay,"TOPLEFT",91,-5)
openGuide:SetFrameLevel(dragArea:GetFrameLevel()+2)
openGuide:SetScript("OnClick",function() GetGear:ShowUI() end)
openGuide:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_BOTTOM")
    GameTooltip:AddLine("Open GetGear guide",1,0.82,0.35)
    GameTooltip:Show()
end)
openGuide:SetScript("OnLeave",HideItemTooltip)
local trackerLevel = NewText(overlay, "GameFontHighlightSmall", 168, "RIGHT")
trackerLevel:SetPoint("TOPRIGHT", -39, -11)
local trackerClose = NewButton(overlay, "X", 25, 22)
trackerClose:SetPoint("TOPRIGHT", -7, -6)
trackerClose:SetFrameLevel(dragArea:GetFrameLevel()+2)
trackerClose:SetScript("OnClick", function() GetGear:ToggleOverlay() end)

local objHead = CreateFrame("Button", nil, overlay)
objHead:SetPoint("TOPLEFT", 10, -65)
objHead:SetSize(326, 24)
local objHeadText = NewText(objHead, "GameFontNormalSmall", 324)
objHeadText:SetPoint("LEFT", 0, 0)
objHead:SetScript("OnClick", function()
    if not GetGear.db then return end
    GetGear.db.overlay.objectivesCollapsed = not GetGear.db.overlay.objectivesCollapsed
    GetGear:RefreshOverlay()
end)

local overlaySlot = NewSlotSelector(overlay, "GetGear_OverlaySlotMenu", "overlay",
    function() GetGear:RefreshOverlay() end)
overlaySlot:SetPoint("TOPLEFT", 10, -37)
local objScroll = CreateFrame("ScrollFrame", nil, overlay, "UIPanelScrollFrameTemplate")
objScroll:SetPoint("TOPLEFT", overlay, "TOPLEFT", 10, -93)
local objContent = CreateFrame("Frame", nil, objScroll)
objContent:SetSize(290, 200)
objScroll:SetScrollChild(objContent)
local overlayRows = {}
wishlistUI.overlayPage,wishlistUI.overlayViewKey=1,nil
wishlistUI.overlayPrevious=NewButton(overlay,"<",22,22)
wishlistUI.overlayNext=NewButton(overlay,">",22,22)
wishlistUI.overlayOther=NewButton(overlay,"Other",48,22)
wishlistUI.overlayStarCount=0
wishlistUI.overlayGroups={wishlistUI.GroupLabel(objContent),wishlistUI.GroupLabel(objContent)}
wishlistUI.overlayPrevious:SetPoint("TOPLEFT",181,-37)
wishlistUI.overlayNext:SetPoint("TOPLEFT",205,-37)
wishlistUI.overlayOther:SetPoint("TOPLEFT",230,-37)
wishlistUI.overlayPrevious:SetScript("OnClick",function() wishlistUI.overlayPage=math.max(1,wishlistUI.overlayPage-1);objScroll:SetVerticalScroll(0);GetGear:RefreshOverlay() end)
wishlistUI.overlayNext:SetScript("OnClick",function() wishlistUI.overlayPage=wishlistUI.overlayPage+1;objScroll:SetVerticalScroll(0);GetGear:RefreshOverlay() end)
wishlistUI.overlayOther:SetScript("OnClick",function() wishlistUI.overlayPage=math.floor(wishlistUI.overlayStarCount/32)+1;objScroll:SetVerticalScroll(0);GetGear:RefreshOverlay() end)

local function NewOverlayRow(i)
    local f = CreateFrame("Frame", nil, objContent)
    f:SetSize(316, 46)
    local bg = f:CreateTexture(nil, "BACKGROUND")
    bg:SetAllPoints()
    local icon = NewIcon(f, 30)
    icon:SetPoint("TOPLEFT", 5, -41)
    local expand = CreateFrame("Button", nil, f)
    expand:SetPoint("TOPLEFT", 41, -34)
    expand:SetSize(229, 46)
    local name = NewText(expand, "GameFontNormalSmall", 227)
    name:SetPoint("TOPLEFT", 2, -7)
    local sub = NewText(expand, "GameFontHighlightSmall", 226)
    local hide = NewButton(f, "X", 25, 22)
    hide:SetPoint("TOPRIGHT", -7, -11)
    hide:SetScript("OnEnter",function(self)
        if not GameTooltip then return end
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine("Hide objective",1,0.82,0.35)
        GameTooltip:AddLine("Does not mark acquired or skipped. Restore in Guide > Hidden.",1,1,1,true)
        GameTooltip:Show()
    end)
    hide:SetScript("OnLeave",HideItemTooltip)
    local minimize = NewButton(f, "-", 25, 22)
    minimize:SetPoint("RIGHT",hide,"LEFT",-4,0)
    minimize:SetScript("OnEnter",function(self)
        if GameTooltip then
            GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
            GameTooltip:AddLine(self.minimized and "Expand objective" or "Minimize objective",1,0.82,0.35)
            GameTooltip:Show()
        end
    end)
    minimize:SetScript("OnLeave",HideItemTooltip)
    local star=wishlistUI.NewStarButton(f)
    star:SetPoint("RIGHT",minimize,"LEFT",-3,0)
    local pin=NewAcquisitionPin(f,22)
    pin:SetPoint("RIGHT",star,"LEFT",-3,0)
    local professionIcon = NewProfessionIcon(f,18)
    local profession = NewText(f,"GameFontHighlightSmall",140)
    local desc = NewText(f, "GameFontHighlightSmall", 295)
    local comparison = NewText(f,"GameFontHighlightSmall",295)
    local benefits = {}
    local matTitle = NewText(f, "GameFontNormalSmall", 296)
    matTitle:SetText("MATERIALS")
    local matNote = NewText(f, "GameFontHighlightSmall", 276)
    local mats = {}
    overlayRows[i] = {f=f,bg=bg,icon=icon,expand=expand,name=name,sub=sub,
        hide=hide,minimize=minimize,pin=pin,star=star,profession=profession,professionIcon=professionIcon,
        desc=desc,comparison=comparison,benefits=benefits,matTitle=matTitle,matNote=matNote,mats=mats}
    return overlayRows[i]
end

-- Measure after assigning width/text on every refresh, including resize and
-- row reuse. Keep the original single-line spacing without a fixed title box.
local function LayoutOverlayHeader(row)
    local subY=7+MeasureText(row.name,12)+7
    row.sub:ClearAllPoints()
    row.sub:SetPoint("TOPLEFT",row.expand,"TOPLEFT",2,-subY)
    local bottom=subY+MeasureText(row.sub,12)
    local headerHeight=math.max(47,bottom+9)
    row.expand:SetHeight(headerHeight)
    return 34+math.max(48,bottom+10),34+headerHeight
end

local matHeader = CreateFrame("Button", nil, overlay)
matHeader:SetSize(332, 28)
local matHeaderText = NewText(matHeader, "GameFontNormalSmall", 210)
matHeaderText:SetPoint("LEFT", 0, 0)
matHeader:SetScript("OnClick", function()
    if not GetGear.db then return end
    GetGear.db.overlay.materialsCollapsed = not GetGear.db.overlay.materialsCollapsed
    GetGear:RefreshOverlay()
end)
matHeader:SetScript("OnEnter", function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine(self.listIncomplete and "Why this list is incomplete" or "Total crafting materials",1,0.82,0.35)
    local undocumented=self.undocumentedCrafts or {}
    if #undocumented>0 then
        GameTooltip:AddLine("Recipe requirements: "..#undocumented.." tracked craft(s) have no documented ingredient list.",1,0.77,0.4,true)
        for i=1,math.min(#undocumented,3) do
            GameTooltip:AddLine("  "..tostring(undocumented[i].name or "Unnamed craft"),0.84,0.85,0.91,true)
        end
        if #undocumented>3 then
            GameTooltip:AddLine("  ...and "..(#undocumented-3).." more; see Guide.",0.76,0.81,0.88)
        end
    else
        GameTooltip:AddLine("Ingredient requirements are documented for the tracked crafts.",0.59,0.87,0.65,true)
    end
    if (self.unscannedBanks or 0)>0 or (self.unscannedBags or 0)>0
        or (self.partialBanks or 0)>0 then
        GameTooltip:AddLine(" ")
        GameTooltip:AddLine("Inventory coverage (same realm/faction):",0.70,0.85,1)
        if (self.unscannedBanks or 0)>0 then
            GameTooltip:AddLine(self.unscannedBanks.." saved character bank(s) not yet scanned.",1,0.78,0.45,true)
        end
        if (self.unscannedBags or 0)>0 then
            GameTooltip:AddLine(self.unscannedBags.." character bag snapshot(s) missing.",1,0.78,0.45,true)
        end
        if (self.partialBanks or 0)>0 then
            GameTooltip:AddLine(self.partialBanks.." character bank(s) scanned incompletely.",1,0.78,0.45,true)
        end
        if self.unscannedNames and #self.unscannedNames>0 then
            GameTooltip:AddLine("Visit bank or log in: "..table.concat(self.unscannedNames,", "),0.85,0.87,0.92,true)
        end
    end
    GameTooltip:AddLine(" ")
    GameTooltip:AddLine("Missing recipe data affects materials NEEDED. Missing bank/alt scans affect materials OWNED, not the recipe requirements.",0.70,0.82,0.94,true)
    GameTooltip:AddLine("Only previously visited characters are recorded; saved counts can become outdated.",0.69,0.73,0.82,true)
    GameTooltip:Show()
end)
matHeader:SetScript("OnLeave",HideItemTooltip)
local scopeButton = nil -- material scope is configured in /getgear settings
-- Dedicated, clearly labelled collapse control instead of a tracking button.
local collapseMaterials=NewButton(overlay,"-",24,22)
collapseMaterials:SetScript("OnClick",function()
    if not GetGear.db then return end
    GetGear.db.overlay.materialsCollapsed=not GetGear.db.overlay.materialsCollapsed
    GetGear:RefreshOverlay()
end)
collapseMaterials:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_LEFT")
    GameTooltip:AddLine(GetGear.db and GetGear.db.overlay.materialsCollapsed and "Expand total materials" or "Minimize total materials",1,0.82,0.35)
    GameTooltip:Show()
end)
collapseMaterials:SetScript("OnLeave",HideItemTooltip)
local matScroll = CreateFrame("ScrollFrame", nil, overlay, "UIPanelScrollFrameTemplate")
local matContent = CreateFrame("Frame", nil, matScroll)
matContent:SetSize(290, 200)
matScroll:SetScrollChild(matContent)
local materialRows = {}
local emptyMaterialText = NewText(matContent, "GameFontHighlightSmall", 300)
emptyMaterialText:SetPoint("TOPLEFT", 3, -8)

local noObjectives = NewText(objContent, "GameFontHighlightSmall", 300)
noObjectives:SetPoint("TOPLEFT", 5, -9)

-- A real splitter between the two independent scrolling sections. The
-- player's chosen ratio is persisted; no dependence on the current item count.
local SIDE_PADDING = 10
local SPLITTER_HEIGHT = 14
local SECTION_START_Y = 93
local BOTTOM_AND_HEADERS = 140
local splitter = CreateFrame("Button", "GetGear_OverlaySectionSplitter", overlay)
splitter:SetHeight(SPLITTER_HEIGHT)
splitter:SetFrameLevel(overlay:GetFrameLevel()+5)
splitter:EnableMouse(true)
local splitRule=splitter:CreateTexture(nil, "BACKGROUND")
splitRule:SetHeight(2)
splitRule:SetPoint("LEFT",5,0)
splitRule:SetPoint("RIGHT",-5,0)
splitRule:SetColorTexture(0.59,0.43,0.19,0.85)
local splitGrip=splitter:CreateTexture(nil,"ARTWORK")
splitGrip:SetSize(54,11)
splitGrip:SetPoint("CENTER",0,0)
splitGrip:SetColorTexture(0.23,0.18,0.11,0.98)
local splitGlyph=NewText(splitter,"GameFontNormalSmall",50,"CENTER")
splitGlyph:SetPoint("CENTER",0,1)
splitGlyph:SetText("= = =")
splitGlyph:SetTextColor(1,0.76,0.33)
splitter:SetScript("OnEnter",function(self)
    if GameTooltip then
        GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
        GameTooltip:AddLine("Resize tracker sections",1,0.82,0.35)
        GameTooltip:AddLine("Drag up for more crafting materials; down for more objectives.",1,1,1,true)
        GameTooltip:Show()
    end
end)
splitter:SetScript("OnLeave",HideItemTooltip)
-- A section drag changes viewport geometry only. The last completed refresh
-- owns row contents; no catalogue/stat/material work belongs on this path.
local sectionLayout
local function LayoutOverlaySections(share)
    local state=sectionLayout
    if not state or not GetGear.db then return end
    local opts=GetGear.db.overlay
    local desiredObj,desiredMat=state.desiredObj,state.desiredMat
    local bothOpen=desiredObj>0 and desiredMat>0
    local dividerSpace=bothOpen and SPLITTER_HEIGHT or 0
    local budget=math.max(0,overlay:GetHeight()-BOTTOM_AND_HEADERS-dividerSpace)
    local objH,matsH=0,0
    if bothOpen then
        share=share or opts.materialShare
        local explicit=type(share)=="number"
        if not explicit then share=math.max(0.45,math.min(0.65,desiredMat/math.max(1,desiredMat+desiredObj))) end
        share=math.max(0.12,math.min(0.88,share))
        local minimum=math.min(36,math.floor(budget/2))
        matsH=math.max(minimum,math.min(budget-minimum,math.floor(budget*share+0.5)))
        objH=budget-matsH
        -- An explicit split is a viewport preference, independent of how many
        -- rows currently fit. Content-based clamping made the grip jump back.
        if not explicit then
            if desiredObj<objH then objH=desiredObj;matsH=math.min(desiredMat,budget-objH)
            elseif desiredMat<matsH then matsH=desiredMat;objH=math.min(desiredObj,budget-matsH) end
        end
        splitter:ClearAllPoints()
        splitter:SetPoint("TOPLEFT",overlay,"TOPLEFT",SIDE_PADDING,-(SECTION_START_Y+objH+3))
        splitter:Show()
    else splitter:Hide() end
    objScroll:SetHeight(objH)
    if objScroll.GetVerticalScroll and objScroll:GetVerticalScroll()>math.max(0,state.totalY-objH) then
        objScroll:SetVerticalScroll(math.max(0,state.totalY-objH))
    end
    local headerY=SECTION_START_Y+objH+6+dividerSpace
    matHeader:ClearAllPoints();matHeader:SetPoint("TOPLEFT",overlay,"TOPLEFT",11,-headerY)
    collapseMaterials:ClearAllPoints();collapseMaterials:SetPoint("TOPRIGHT",overlay,"TOPRIGHT",-11,-headerY-3)
    matScroll:ClearAllPoints();matScroll:SetPoint("TOPLEFT",overlay,"TOPLEFT",9,-headerY-32)
    matScroll:SetHeight(matsH)
    if matScroll.GetVerticalScroll and matScroll:GetVerticalScroll()>math.max(0,state.totalMatsH-matsH) then
        matScroll:SetVerticalScroll(math.max(0,state.totalMatsH-matsH))
    end
end
local function UpdateSplitFromCursor()
    if not GetGear.db or not sectionLayout or type(GetCursorPosition)~="function" then return end
    local scale=overlay.GetEffectiveScale and overlay:GetEffectiveScale() or 1
    if not scale or scale<=0 then scale=1 end
    local _,cursorY=GetCursorPosition()
    if type(cursorY)~="number" or type(overlay:GetTop())~="number" then return end
    local budget=math.max(0,overlay:GetHeight()-BOTTOM_AND_HEADERS-SPLITTER_HEIGHT)
    if budget<72 then return end
    local objectiveHeight=overlay:GetTop()-cursorY/scale-SECTION_START_Y-3
    objectiveHeight=math.max(36,math.min(budget-36,objectiveHeight))
    local share=math.max(0.12,math.min(0.88,(budget-objectiveHeight)/budget))
    -- Skip unchanged physical pixels, without adding lag or writing settings.
    local pixel=math.floor(budget*share+0.5)
    if splitter.lastPixel==pixel then return end
    splitter.lastPixel=pixel;splitter.pendingShare=share
    LayoutOverlaySections(share)
end
local function FinishSectionDrag(self)
    if not self.dragging then return end
    self.dragging=false;self:SetScript("OnUpdate",nil)
    if GetGear.db and self.pendingShare then GetGear.db.overlay.materialShare=self.pendingShare end
    self.pendingShare=nil;self.lastPixel=nil
end
splitter:SetScript("OnMouseDown",function(self,button)
    if button~="LeftButton" then return end
    self.dragging=true;self.lastPixel=nil
    HideItemTooltip();UpdateSplitFromCursor()
    self:SetScript("OnUpdate",function(grip)
        if type(IsMouseButtonDown)=="function" and not IsMouseButtonDown("LeftButton") then
            UpdateSplitFromCursor();FinishSectionDrag(grip);return
        end
        UpdateSplitFromCursor()
    end)
end)
splitter:SetScript("OnMouseUp",function(self,button)
    if button=="LeftButton" and self.dragging then UpdateSplitFromCursor();FinishSectionDrag(self) end
end)
splitter:SetScript("OnHide",FinishSectionDrag)

local function UpdateOverlayWidths()
    local width=overlay:GetWidth()
    -- Both stock scrollbars sit 6px OUTSIDE their scroll-frame edge and
    -- consume another 16px. Reserve a consistent dark gutter on both lists
    -- so blue objective cards never run beneath either scrollbar.
    local rowW=math.max(280,width-2*SIDE_PADDING)
    local scrollW=math.max(254,rowW-26)
    -- Reserve header space for the Guide button and character label.
    -- Only the GetGear title itself serves as the drag handle.
    dragArea:SetWidth(82)
    trackerLevel:SetWidth(math.max(95,width-190))
    objHead:SetWidth(rowW)
    objHeadText:SetWidth(rowW-2)
    objScroll:SetWidth(scrollW)
    objContent:SetWidth(scrollW)
    noObjectives:SetWidth(scrollW-10)
    matHeader:SetWidth(rowW)
    matHeaderText:SetWidth(rowW-48)
    matScroll:SetWidth(scrollW)
    matContent:SetWidth(scrollW)
    emptyMaterialText:SetWidth(scrollW-12)
    splitter:SetWidth(rowW)
    for _,r in ipairs(overlayRows) do
        r.f:SetWidth(scrollW)
        r.expand:SetWidth(scrollW-48)
        r.name:SetWidth(scrollW-52)
        r.sub:SetWidth(scrollW-52)
        r.desc:SetWidth(scrollW-20)
        r.comparison:SetWidth(scrollW-20)
        r.matTitle:SetWidth(scrollW-20)
    end
end

local function IsInCombat()
    return type(InCombatLockdown) == "function" and InCombatLockdown()
end

-- Keep the trade skill requirement with the relevant item's Materials
-- heading, rather than adding a separate metadata line below its level.
-- No redundant profession icon: the required skill is printed in full.
local function ShowOverlayMaterialHeader(row, gear, y)
    row.matTitle:ClearAllPoints()
    row.matTitle:SetPoint("TOPLEFT", row.f, "TOPLEFT", 11, -y)
    row.matTitle:SetWidth(82)
    row.matTitle:SetText("MATERIALS")
    row.matTitle:Show()
    local professionShown=UpdateProfessionSkill(row.professionIcon, row.profession, gear, true)
    if professionShown then
        row.professionIcon:Hide()
        row.profession:SetWidth(math.max(80,row.f:GetWidth()-115))
        row.profession:SetJustifyH("RIGHT")
        row.profession:ClearAllPoints()
        row.profession:SetPoint("TOPRIGHT", row.f, "TOPRIGHT", -11, -y)
    end
    return math.max(MeasureText(row.matTitle,12),professionShown and MeasureText(row.profession,12) or 0)+5
end

local function RefreshOverlay(self)
    if not self.db then return end
    local opts = self.db.overlay
    local opacity = math.max(0.2, math.min(1, opts.backgroundOpacity or 0.78))
    background:SetColorTexture(0.045, 0.065, 0.10, opacity)
    local shouldShow = opts.visible and not (opts.hideInCombat and IsInCombat())
    if not shouldShow then overlay:Hide(); return end
    overlay:Show()
    UpdateOverlayWidths()
    trackerLevel:SetWidth(math.max(60,overlay:GetWidth()-218))
    local race = type(UnitRace)=="function" and UnitRace("player") or nil
    local class = type(UnitClass)=="function" and UnitClass("player") or nil
    local classToken = type(UnitClass)=="function" and select(2,UnitClass("player")) or nil
    trackerLevel:SetText(ColoredCharacterLabel(self.level, race, class, classToken))

    local selectionStarted=self.performanceStats and self:PerformanceClock()
    local list = wishlistUI.starPresentationOnly and wishlistUI.overlayModel or self:GetItems("tracker")
    -- These are independent overlay presentation filters. Neither affects
    -- the full guide, saved progress, or the catalogue's source research.
    if not wishlistUI.starPresentationOnly and (self.ShouldShowOverlayStatChanges or self.ShouldShowOverlayWorldBoEDrops or self.ShouldShowOverlayAcquisition) then
        local visible={}
        for _,gear in ipairs(list) do
            local useful=not self.ShouldShowOverlayStatChanges
                or self:ShouldShowOverlayStatChanges(gear)
            local obtainable=(opts.hideGreenBoEWorldDrops==false)
                or not self.ShouldShowOverlayWorldBoEDrops
                or self:ShouldShowOverlayWorldBoEDrops(gear)
            local accessible=not self.ShouldShowOverlayAcquisition or self:ShouldShowOverlayAcquisition(gear)
            if useful and obtainable and accessible then visible[#visible+1]=gear end
        end
        list=visible
    end
    wishlistUI.overlayModel=list
    if self.ComposeStarredItems then list=self:ComposeStarredItems(list,"tracker",wishlistUI.starPresentationOnly and wishlistUI.overlayStarModel or nil,true);wishlistUI.overlayStarModel=wishlistUI.RememberStars(list) end
    -- Slot filtering is last: counts and matches respect every existing stat,
    -- world-drop and acquisition visibility rule before limiting rendered rows.
    overlaySlot:Update()
    local slot = self:GetEquipmentSlotFilter("overlay")
    local total
    list, total = self:FilterEquipmentSlots(list, slot)
    if self.performanceStats then self:RecordPerformancePhase("OverlaySelection",selectionStarted) end
    local rowsStarted=self.performanceStats and self:PerformanceClock()
    local overlayCap = 32
    local matches=#list
    local key=slot
    if wishlistUI.overlayViewKey~=key then wishlistUI.overlayPage=1;wishlistUI.overlayViewKey=key end
    local pages=math.max(1,math.ceil(matches/overlayCap))
    wishlistUI.overlayPage=math.min(wishlistUI.overlayPage,pages)
    wishlistUI.overlayStarCount=0
    for _,gear in ipairs(list) do
        if self.IsItemStarred and self:IsItemStarred(gear.itemID) then wishlistUI.overlayStarCount=wishlistUI.overlayStarCount+1 end
    end
    wishlistUI.overlayPrevious:SetShown(pages>1);wishlistUI.overlayNext:SetShown(pages>1)
    wishlistUI.overlayPrevious:SetEnabled(wishlistUI.overlayPage>1);wishlistUI.overlayNext:SetEnabled(wishlistUI.overlayPage<pages)
    wishlistUI.overlayOther:SetShown(wishlistUI.overlayStarCount>0 and wishlistUI.overlayStarCount<matches and pages>1)
    local subset={}
    for i=(wishlistUI.overlayPage-1)*overlayCap+1,math.min(matches,wishlistUI.overlayPage*overlayCap) do subset[#subset+1]=list[i] end
    list=subset
    local displayed = opts.objectivesCollapsed and 0 or math.min(#list,overlayCap)
    objHeadText:SetText((opts.objectivesCollapsed and "+" or "-") .. "  " ..
        self:EquipmentSlotCountText(matches, total, displayed)..(pages>1 and wishlistUI.overlayStarCount>0 and ("  |  "..wishlistUI.overlayPage.."/"..pages) or ""))
    if wishlistUI.starPresentationOnly and not opts.objectivesCollapsed then wishlistUI.ReusePresentationRows(overlayRows,list,NewOverlayRow) end
    local totalY = 0
    for _,label in ipairs(wishlistUI.overlayGroups) do label:Hide() end
    local lastGroup,groupIndex=nil,0
    if opts.objectivesCollapsed then
        objScroll:Hide()
    else
        objScroll:Show()
        if #list == 0 then
            noObjectives:SetText(slot~="all" and "No recommendations for this slot."
                or #self.Gear == 0 and self:GetGuideEmptyMessage()
                or "No current objectives. Check Earlier Gear, Hidden or Completed in /getgear.")
            noObjectives:Show()
            totalY = 44
        else
            noObjectives:Hide()
            -- The compact overlay is a quick tracker, not a thousands-row catalogue.
            -- Browse the entire objective list in /getgear (paged above).
            for i=1,math.min(#list,overlayCap) do
                local gear = list[i]
                local group=self.IsItemStarred and self:IsItemStarred(gear.itemID) and "Starred Items" or "Other Recommendations"
                if self.db.starredItems and next(self.db.starredItems) and group~=lastGroup then
                    groupIndex=groupIndex+1
                    local label=wishlistUI.overlayGroups[groupIndex]
                    label:ClearAllPoints();label:SetPoint("TOPLEFT",objContent,"TOPLEFT",5,-totalY)
                    label:SetText(group=="Starred Items" and (group.." ("..wishlistUI.overlayStarCount..")") or group);label:Show();totalY=totalY+23;lastGroup=group
                end
                local r = overlayRows[i] or NewOverlayRow(i)
                r.f:SetWidth(objContent:GetWidth())
                r.f:ClearAllPoints()
                r.f:SetPoint("TOPLEFT", objContent, "TOPLEFT", 0, -totalY)
                r.f:Show()
                wishlistUI.AssignStar(r.star,gear,false)
                if wishlistUI.starPresentationOnly and r.gear and r.gear.itemID==gear.itemID then
                    r.f:Show();totalY=totalY+r.f:GetHeight()+4
                else
                if self:IsItemStarred(gear.itemID) then gear=self:GetRecommendationRecord(gear) end
                r.gear=gear
                r.bg:SetColorTexture(0.10, 0.13, 0.19, opacity*0.9)
                r.desc:SetWidth(r.f:GetWidth()-20)
                r.comparison:SetWidth(r.f:GetWidth()-23)
                r.matNote:SetWidth(r.f:GetWidth()-22)
                SetItemIcon(r.icon, gear.itemID,nil,nil,gear)
                AssignAcquisitionPin(r.pin,gear)
                local restriction=self:IsItemStarred(gear.itemID) and self:GetSearchRestriction(gear,true)
                if restriction then r.pin:Hide() end
                wishlistUI.LayoutActions(r.f,{r.hide,r.minimize,r.pin,r.star})
                r.expand:SetWidth(r.f:GetWidth()-48)
                r.name:SetWidth(r.f:GetWidth()-52)
                r.sub:SetWidth(r.f:GetWidth()-52)
                r.name:SetText(gear.name .. (gear.bagUpgrade and ("  x"..gear.quantity) or ""))
                r.sub:SetText(gear.bagUpgrade and (tostring(gear.bagSlots).." slots each | "..gear.quantity.." needed") or ((gear.targetLevel>(self.level or 1) and "Future | " or "").."Level " .. tostring(gear.targetLevel)))
                local contentY,headerHeight=LayoutOverlayHeader(r)
                r.expand:SetScript("OnClick", function()
                    opts.expanded[gear.id] = not opts.expanded[gear.id] or nil
                    self:RefreshOverlay()
                end)
                r.hide:SetScript("OnClick", function() self:SetHidden(gear, true) end)
                r.hide:Show()
                local minimized = opts.minimized[gear.id] == true
                r.minimize.minimized=minimized
                r.minimize:SetText(minimized and "+" or "-")
                r.minimize:SetScript("OnClick",function()
                    if minimized then
                        opts.minimized[gear.id] = nil
                    else
                        opts.minimized[gear.id] = true
                    end
                    self:RefreshOverlay()
                end)
                -- Minimized objectives retain their header (icon/name/level)
                -- and continue contributing to the aggregate materials tracker.
                -- Full objectives retain their prior title-click detail toggle.
                if minimized then
                    r.comparison:Hide()
                    r.professionIcon:Hide(); r.profession:Hide()
                    r.desc:Hide(); r.matTitle:Hide(); r.matNote:Hide()
                    for _, w in ipairs(r.benefits) do w:Hide() end
                    for _, w in ipairs(r.mats) do w.frame:Hide() end
                    r.f:SetHeight(headerHeight)
                    r.f:Show()
                    totalY=totalY+headerHeight+4
                else
                -- The compact tracker ALWAYS displays the per-item material
                -- checklist, including for objectives within the next 5 levels.
                -- Expanding adds benefits and useful source detail; status actions stay in the full Guide.
                local nextY = contentY
                -- The trade-skill requirement is rendered beside the item's
                -- Materials heading below, not between level and stat deltas.
                local changeText,showChange="",false
                if not gear.bagUpgrade then changeText,showChange=self:ComparisonInline(gear,false) end
                if showChange and changeText ~= "" then
                    r.comparison:ClearAllPoints()
                    r.comparison:SetPoint("TOPLEFT",r.f,"TOPLEFT",11,-nextY)
                    r.comparison:SetWidth(r.f:GetWidth()-23)
                r.matNote:SetWidth(r.f:GetWidth()-22)
                    r.comparison:SetText(changeText)
                    r.comparison:Show()
                    -- Match the deliberate gap above the stat block, measured
                    -- from its final wrapped line, not its first line.
                    -- Allow one-line strings to use their measured height. The
                    -- old 17px minimum added whitespace to short stat lines;
                    -- actual two-or-more-line measurements stay unchanged.
                    nextY=nextY+MeasureText(r.comparison,12)+14
                else
                    r.comparison:Hide()
                end
                local expanded = opts.expanded[gear.id]
                -- Acquisition must be visible at a glance, not hidden behind
                -- an expand click. Detailed source notes still appear expanded.
                local summary = self.GetAcquisitionSummary and self:GetAcquisitionSummary(gear)
                if restriction then summary="Unavailable: "..restriction..(summary and ("\n"..summary) or "") end
                if expanded then
                    local detail=DescribeOverlay(gear,r.pin:IsShown())
                    if detail and detail~="" then
                        if summary and summary~="" and not detail:find(summary,1,true) then
                            summary=summary.."\n"..detail
                        else
                            summary=detail
                        end
                    end
                end
                if summary and summary~="" then
                    r.desc:ClearAllPoints()
                    r.desc:SetPoint("TOPLEFT", r.f, "TOPLEFT", 11, -nextY)
                    r.desc:SetText(summary)
                    r.desc:Show()
                    -- Use measured wrapped text height, including the brief
                    -- source shown before expansion.
                    nextY = nextY + MeasureText(r.desc, 12) + 5
                else
                    r.desc:Hide()
                end
                for _,widget in ipairs(r.benefits) do widget:Hide() end

                local reagents = self:GetCraftingMaterialRows(gear)
                if #reagents > 0 then
                    nextY=nextY+ShowOverlayMaterialHeader(r, gear, nextY)
                    r.matNote:Hide()
                    for j, mat in ipairs(reagents) do
                        local widget = r.mats[j]
                        if not widget then widget=NewReagent(r.f,true);r.mats[j]=widget end
                        UpdateReagent(widget,mat,9 + math.min(mat.depth or 0, 2)*14,nextY+(j-1)*28,r.f,false)
                    end
                    nextY = nextY + #reagents*28 + 5
                else
                    if gear.bagUpgrade and gear.profession then
                        -- Show the craft threshold even when the player is not
                        -- a Tailor (and hence we don't track their reagents).
                        nextY=nextY+ShowOverlayMaterialHeader(r, gear, nextY)
                        r.matTitle:SetText("CRAFTING")
                        r.matNote:ClearAllPoints()
                        r.matNote:SetPoint("TOPLEFT",r.f,"TOPLEFT",11,-nextY)
                        r.matNote:SetText("Buy, commission, or learn Tailoring")
                        r.matNote:Show()
                        nextY = nextY + MeasureText(r.matNote,12)+5
                    elseif self.IsCraftMaterialsUnknown and self:IsCraftMaterialsUnknown(gear) then
                        nextY=nextY+ShowOverlayMaterialHeader(r, gear, nextY)
                        r.matNote:ClearAllPoints()
                        r.matNote:SetPoint("TOPLEFT", r.f, "TOPLEFT", 11, -nextY)
                        r.matNote:SetText("Materials not yet documented")
                        r.matNote:Show()
                        nextY = nextY + MeasureText(r.matNote,12)+5
                    else
                        r.matTitle:Hide()
                        r.matNote:Hide()
                        r.professionIcon:Hide(); r.profession:Hide()
                    end
                end
                for j=#reagents+1,#r.mats do r.mats[j].frame:Hide() end

                r.f:SetHeight(nextY)
                r.f:Show()
                totalY=totalY+nextY+4
                end -- not minimized
                end -- reuse rendered row on a star click
            end
        end
    end
    for i=(opts.objectivesCollapsed and 1 or math.min(#list,32)+1),#overlayRows do overlayRows[i].f:Hide() end
    if self.performanceStats then self:RecordPerformancePhase("OverlayObjectiveUI",rowsStarted) end
    if wishlistUI.starPresentationOnly then
        sectionLayout.desiredObj=opts.objectivesCollapsed and 0 or math.max(45,totalY)
        sectionLayout.totalY=totalY
        objContent:SetHeight(math.max(50,totalY))
        wishlistUI.CommitScrollLayout(objScroll)
        LayoutOverlaySections(splitter.dragging and splitter.pendingShare)
        return
    end
    -- A collapsed total has no visible rows. Requirements are rebuilt from
    -- current state on expansion; per-objective materials remain independent.
    local materials = not opts.materialsCollapsed and self:GetCombinedMaterialRows(opts.materialScope) or {}
    local materialUIStarted=self.performanceStats and self:PerformanceClock()
    local totalMatsH=math.max(42,#materials*29+7)
    local desiredObj = opts.objectivesCollapsed and 0 or math.max(45,totalY)
    local desiredMat = opts.materialsCollapsed and 0 or totalMatsH
    local bothOpen = desiredObj>0 and desiredMat>0
    local dividerSpace = bothOpen and SPLITTER_HEIGHT or 0
    -- Auto-fit only until the first user resize. Give Materials more space by
    -- default so the aggregate list is usable even with many active crafts.
    if type(opts.height) ~= "number" then
        overlay:SetHeight(BOTTOM_AND_HEADERS + dividerSpace
            + math.min(desiredObj,280) + math.min(desiredMat,215))
    end
    sectionLayout={desiredObj=desiredObj,desiredMat=desiredMat,totalY=totalY,totalMatsH=totalMatsH}
    objContent:SetHeight(math.max(50,totalY))
    wishlistUI.CommitScrollLayout(objScroll)
    local missing = self:GetUndocumentedCrafts(opts.materialScope)
    -- The ingredient requirements and the account-owned inventory are
    -- separate concepts. Surface either gap, but explain which is affected
    -- in the hover text rather than implying all recipes lack materials.
    local missingBanks,missingBags,partialBanks=0,0,0
    local unscannedNames={}
    if self.AltInventory and self.AltInventory.BrowserCharacters then
        for _,character in ipairs(self.AltInventory:BrowserCharacters()) do
            if character.eligible then
                local bankMissing=not character.bankKnown
                local bagsMissing=not character.bagsKnown
                local bankPartial=character.bankPartial==true
                if bankMissing then missingBanks=missingBanks+1 end
                if bagsMissing then missingBags=missingBags+1 end
                if bankPartial then partialBanks=partialBanks+1 end
                if bankMissing or bagsMissing or bankPartial then
                    if #unscannedNames<4 then unscannedNames[#unscannedNames+1]=character.name or "Unknown" end
                end
            end
        end
    end
    matHeader.undocumentedCrafts=missing
    matHeader.unscannedBanks=missingBanks
    matHeader.unscannedBags=missingBags
    matHeader.partialBanks=partialBanks
    matHeader.unscannedNames=unscannedNames
    matHeader.listIncomplete=(#missing>0 or missingBanks>0 or missingBags>0 or partialBanks>0)
    matHeaderText:SetText(matHeader.listIncomplete and "TOTAL MATERIALS (INCOMPLETE LIST)" or "TOTAL MATERIALS")
    collapseMaterials:SetText(opts.materialsCollapsed and "+" or "-")
    if opts.materialsCollapsed then
        matScroll:Hide()
    else
        matScroll:Show()
        if #materials == 0 then
            emptyMaterialText:SetText(#missing>0 and ("Materials missing for " .. #missing .. " craft(s); total is incomplete.") or "No documented materials needed for these objectives.")
            emptyMaterialText:Show()
        else
            emptyMaterialText:Hide()
        end
        for i, material in ipairs(materials) do
            local r=materialRows[i]
            if not r then r=NewReagent(matContent,true);materialRows[i]=r end
            UpdateReagent(r,material,3 + math.min(material.depth or 0, 2)*14,4+(i-1)*29,matContent,true)
        end
        for i=#materials+1,#materialRows do materialRows[i].frame:Hide() end
        matContent:SetHeight(totalMatsH)

    end
    LayoutOverlaySections(splitter.dragging and splitter.pendingShare)
    if self.RefreshItemSearchUI then self:RefreshItemSearchUI(true) end
    if self.performanceStats then self:RecordPerformancePhase("OverlayMaterialUI",materialUIStarted) end
end

function GetGear:RefreshOverlay()
    if self.WithRecommendationSnapshot then return self:WithRecommendationSnapshot(RefreshOverlay) end
    return RefreshOverlay(self)
end

function GetGear:RefreshStarPresentation(itemID,starred)
    local record=starred and self:GetSearchRecord(itemID)
    if record and not self:IsHidden(record) and not self:GetStatus(record)
        and not self:IsGearEquipped(record) then
        wishlistUI.detailStarModel[itemID]=record
        wishlistUI.overlayStarModel[itemID]=wishlistUI.detailStarModel[itemID]
    end
    if starred then
        wishlistUI.overlayPage=1;detailPage=1
        objScroll:SetVerticalScroll(0);scroll:SetVerticalScroll(0)
    end
    wishlistUI.starPresentationOnly=true
    local ok,err=pcall(function()
        if window:IsShown() and not inventoryMode then
            if preview.active then
                for _,row in ipairs(detailRows) do
                    if row.gear then wishlistUI.AssignStar(row.star,row.gear,true) end
                end
            else self:RefreshUI() end
        end
        if overlay:IsShown() then self:RefreshOverlay() end
        if self.RefreshItemSearchUI then self:RefreshItemSearchUI() end
    end)
    wishlistUI.starPresentationOnly=false
    if not ok then error(err,0) end
end

AllowResizing(overlay,320,230,580,950)
function overlay:afterResize()
    if GetGear.db then
        local opts=GetGear.db.overlay
        opts.width,opts.height=math.floor(self:GetWidth()+0.5),math.floor(self:GetHeight()+0.5)
        opts.x,opts.y=self:GetLeft(),self:GetTop()
    end
    GetGear:RefreshOverlay()
end
function GetGear:ToggleOverlay()
    if not self.db then return end
    local opts=self.db.overlay
    opts.visible=not opts.visible
    self:RefreshOverlay()
end

-- =====================================================================
-- Settings in separate window; overlay stays uncluttered while playing.
-- =====================================================================
local settings = CreateFrame("Frame", "GetGear_OverlaySettings", UIParent, "BasicFrameTemplateWithInset")
settings:SetSize(780, 692)
settings:SetPoint("CENTER", UIParent, "CENTER", 0, 0)
settings:SetClampedToScreen(true)
local function FitSettingsToScreen()
    local width=UIParent.GetWidth and UIParent:GetWidth() or 780
    local height=UIParent.GetHeight and UIParent:GetHeight() or 692
    settings:SetScale(math.min(1,math.max(1,width-24)/780,math.max(1,height-24)/692))
end
for _,event in ipairs({"DISPLAY_SIZE_CHANGED","UI_SCALE_CHANGED"}) do pcall(settings.RegisterEvent,settings,event) end
settings:SetScript("OnEvent",function()
    if settings:IsShown() then FitSettingsToScreen() end
    if GetGear.db and GetGear.db.overlay.visible then GetGear:RefreshOverlay() end
end)
-- Settings must still be usable when opened from the foreground detail guide.
settings:SetFrameStrata("DIALOG")
if settings.SetToplevel then settings:SetToplevel(true) end
settings:Hide()
if settings.TitleText then settings.TitleText:SetText("GetGear - Display Settings") end
if UISpecialFrames then table.insert(UISpecialFrames,"GetGear_OverlaySettings") end

local helperText=NewText(settings,"GameFontHighlightSmall",340)
helperText:SetPoint("TOPLEFT",17,-40)
helperText:SetText("Transparency affects only the tracker background, never text or item icons.")
local sliderTitle=NewText(settings,"GameFontNormal",330)
sliderTitle:SetPoint("TOPLEFT",18,-80)
sliderTitle:SetText("Background opacity")
local alphaSlider=CreateFrame("Slider", "GetGear_OpacitySlider", settings, "OptionsSliderTemplate")
alphaSlider:SetPoint("TOPLEFT",25,-106)
alphaSlider:SetSize(244,18)
alphaSlider:SetMinMaxValues(20,100)
alphaSlider:SetValueStep(5)
if alphaSlider.SetObeyStepOnDrag then alphaSlider:SetObeyStepOnDrag(true) end
local alphaValue=NewText(settings,"GameFontNormal",90,"RIGHT")
alphaValue:SetPoint("LEFT",alphaSlider,"RIGHT",17,0)
alphaSlider:SetScript("OnValueChanged",function(_,value)
    local rounded=math.floor((value+2.5)/5)*5
    rounded=math.max(20,math.min(100,rounded))
    alphaValue:SetText(rounded .. "%")
    if GetGear.db then
        GetGear.db.overlay.backgroundOpacity=rounded/100
        GetGear:RefreshOverlay()
    end
end)

local function AddScaleSlider(name,y,label,which)
    local title=NewText(settings,"GameFontNormal",340)
    title:SetPoint("TOPLEFT",18,-y)
    title:SetText(label)
    local slider=CreateFrame("Slider",name,settings,"OptionsSliderTemplate")
    slider:SetPoint("TOPLEFT",25,-y-26)
    slider:SetSize(244,18)
    slider:SetMinMaxValues(70,150)
    slider:SetValueStep(5)
    if slider.SetObeyStepOnDrag then slider:SetObeyStepOnDrag(true) end
    local display=NewText(settings,"GameFontNormal",90,"RIGHT")
    display:SetPoint("LEFT",slider,"RIGHT",17,0)
    slider:SetScript("OnValueChanged",function(_,value)
        local rounded=math.max(70,math.min(150,math.floor((value+2.5)/5)*5))
        display:SetText(rounded .. "%")
        if GetGear.db then
            GetGear.db[which].scale=rounded/100
            if which=="overlay" then overlay:SetScale(rounded/100)
            else window:SetScale(rounded/100) end
        end
    end)
    return slider
end
local overlayScaleSlider=AddScaleSlider("GetGear_OverlayScaleSlider",150,"Overlay UI scale","overlay")
local detailScaleSlider=AddScaleSlider("GetGear_DetailScaleSlider",218,"Detailed window UI scale","detail")

local displayChecks={}
local function LayoutDisplayChecks()
    table.sort(displayChecks,function(a,b) return a.label:lower()<b.label:lower() end)
    for index,entry in ipairs(displayChecks) do
        entry.checkbox:ClearAllPoints()
        entry.checkbox:SetPoint("TOPLEFT",18,-292-(index-1)*33)
    end
end
local function NewCheck(parent,label,callback)
    local checkbox=CreateFrame("CheckButton",nil,parent,"UICheckButtonTemplate")
    checkbox:SetSize(25,25)
    local text=NewText(parent,"GameFontHighlight",325)
    text:SetPoint("LEFT",checkbox,"RIGHT",3,0)
    text:SetText(label)
    checkbox:SetScript("OnClick",function(self)
        if GetGear.db then callback(self:GetChecked() and true or false) end
    end)
    displayChecks[#displayChecks+1]={label=label,checkbox=checkbox}
    LayoutDisplayChecks()
    return checkbox
end
local lockedCheck=NewCheck(settings,"Lock overlay position",function(v)
    GetGear.db.overlay.locked=v
end)
local combatCheck=NewCheck(settings,"Hide tracker automatically during combat",function(v)
    GetGear.db.overlay.hideInCombat=v
    GetGear:RefreshOverlay()
end)
-- This filter never edits hidden/acquired SavedVariables. Disabled means
-- older recommendations return to Available Now and the overlay.
local obsoleteCheck=NewCheck(settings,"Filter clearly outclassed earlier gear",function(v)
    GetGear.db.overlay.filterObsolete=v
    GetGear:RefreshAll()
end)
obsoleteCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Conservative earlier gear filtering",1,0.82,0.35)
    GameTooltip:AddLine("Moves clearly outclassed older armour and ordinary weapons to Earlier Gear; matching equipped items appear in Completed.",1,1,1,true)
    GameTooltip:AddLine("Separate from the five-level lookback on bulk-imported gear. Older imported gear moves to Earlier Gear unless Show all valid equipment is enabled.",0.7,0.8,1,true)
    GameTooltip:Show()
end)
obsoleteCheck:SetScript("OnLeave",HideItemTooltip)
local bagsCheck=NewCheck(settings,"Recommend ordinary bag upgrades",function(v)
    GetGear.db.overlay.bagUpgrades=v
    GetGear:RefreshAll()
end)
bagsCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Automatic bag upgrades",1,0.82,0.35)
    GameTooltip:AddLine("Scans four worn bag slots, excluding specialty/reagent bags. Crafting materials include every needed copy when Tailoring is learned.",1,1,1,true)
    GameTooltip:AddLine("Bag objectives disappear automatically when the bags are replaced. No saved gear statuses are modified.",0.7,0.8,1,true)
    GameTooltip:Show()
end)
bagsCheck:SetScript("OnLeave",HideItemTooltip)
-- This is only a display filter: it does not modify gear statuses or
-- hide quest/dungeon/vendor objectives. Preview Guide stays unrestricted.
local craftFilterCheck=NewCheck(settings,"Hide crafted gear I can't make",function(v)
    GetGear.db.overlay.hideUncraftableCrafts=v
    GetGear:RefreshAll()
end)
craftFilterCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Hide uncraftable gear",1,0.82,0.35)
    GameTooltip:AddLine("Off by default. When enabled, crafted-only gear appears only if this character has the profession, meets confirmed skill requirements, and GetGear can confirm the recipe is learned.",1,1,1,true)
    GameTooltip:AddLine("Other acquisition routes, bags, progress history and Preview Guide remain visible. Open your profession window once after login to let GetGear detect known recipes.",0.72,0.83,1,true)
    GameTooltip:Show()
end)
craftFilterCheck:SetScript("OnLeave",HideItemTooltip)
-- All class-equipable gear, including off-role/novelty, is opt-in. Hard
-- exclusions for QA and internal placeholders always remain excluded.
local allValidGearCheck=NewCheck(settings,"Show all valid equipment (including off-spec)",function(v)
    GetGear.db.overlay.showAllValidGear=v
    GetGear:RefreshAll()
end)
allValidGearCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Expanded equipment catalogue",1,0.82,0.35)
    GameTooltip:AddLine("Off by default. Restores off-role and older bulk-imported equipment (five or more levels below you), plus novelty gear such as Winter Hats.",1,1,1,true)
    GameTooltip:AddLine("Internal QA/test and placeholder items remain excluded. Existing acquired/hidden states are not changed. Also applies to Preview Guide.",0.72,0.83,1,true)
    GameTooltip:Show()
end)
allValidGearCheck:SetScript("OnLeave",HideItemTooltip)
-- Only suppress conclusively non-improving items on the tracker. Pending
-- comparisons stay visible and all gear remains in the detailed guide.
local positiveStatCheck=NewCheck(settings,"Hide gear without positive stat changes",function(v)
    GetGear.db.overlay.hideWithoutPositiveStats=v
    GetGear:RefreshOverlay()
end)
positiveStatCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Overlay upgrade comparison",1,0.82,0.35)
    GameTooltip:AddLine("On by default. Uses confirmed gains and losses for a clear talent build; otherwise requires a useful positive stat. Armour-only improvements are optional.",1,1,1,true)
    GameTooltip:AddLine("Missing comparison data, equipment empty slots, bag upgrades and the full Guide are unaffected.",0.72,0.83,1,true)
    GameTooltip:Show()
end)
positiveStatCheck:SetScript("OnLeave",HideItemTooltip)
-- This is only a display rule for generic world drops. A green BoE
-- crafted item or a targetable boss/trash/quest reward is not filtered.
local greenBoECheck=NewCheck(settings,"Hide green BoE world drops from tracker",function(v)
    GetGear.db.overlay.hideGreenBoEWorldDrops=v
    GetGear:RefreshOverlay()
end)
greenBoECheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Optional world-drop suppression",1,0.82,0.35)
    GameTooltip:AddLine("On by default. Hide uncommon (green), Bind-on-Equip WORLD drops that cannot be targeted like quest, dungeon or crafting rewards.",1,1,1,true)
    GameTooltip:AddLine("Crafted BoEs, dungeon drops, quest rewards and the full Guide remain visible. You can switch this off at any time.",0.72,0.83,1,true)
    GameTooltip:Show()
end)
greenBoECheck:SetScript("OnLeave",HideItemTooltip)
-- Class alone does not imply a tank role. This opt-in restores armor-only
-- recommendations without changing the full guide or other stat deltas.
local armorOnlyCheck=NewCheck(settings,"Count armour-only improvements",function(v)
    GetGear.db.overlay.countArmorOnlyUpgrades=v
    GetGear:RefreshOverlay()
end)
armorOnlyCheck:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Armour-only overlay improvements",1,0.82,0.35)
    GameTooltip:AddLine("Off by default for every class. Enable when you want added armour alone to keep an item in the tracker, such as while playing a tank.",1,1,1,true)
    GameTooltip:AddLine("All other improvements, the complete Guide, and comparative armour numbers are unaffected.",0.72,0.83,1,true)
    GameTooltip:Show()
end)
armorOnlyCheck:SetScript("OnLeave",HideItemTooltip)
-- Keep the Tracked/All material-scope choice in settings, without
-- confusing it with the Total Materials minimize button.
local materialScopeButton=NewButton(settings,"",185,23)
materialScopeButton:SetPoint("TOPLEFT",18,-604)
materialScopeButton:SetScript("OnClick",function(self)
    if not GetGear.db then return end
    local opts=GetGear.db.overlay
    opts.materialScope = opts.materialScope == "tracked" and "all" or "tracked"
    self:SetText("Materials: " .. (opts.materialScope == "all" and "All" or "Tracked"))
    GetGear:RefreshOverlay()
end)
materialScopeButton:SetScript("OnEnter",function(self)
    if not GameTooltip then return end
    GameTooltip:SetOwner(self,"ANCHOR_RIGHT")
    GameTooltip:AddLine("Material tally scope",1,0.82,0.35)
    GameTooltip:AddLine("Tracked: visible objectives only",1,1,1)
    GameTooltip:AddLine("All: also includes hidden and earlier objectives",1,1,1)
    GameTooltip:Show()
end)
materialScopeButton:SetScript("OnLeave",HideItemTooltip)
local showOverlay=NewButton(settings,"Show / hide tracker",165,24)
showOverlay:SetPoint("BOTTOMLEFT",20,18)
showOverlay:SetScript("OnClick",function() GetGear:ToggleOverlay() end)

local priorityTitle=NewText(settings,"GameFontNormal",325)
priorityTitle:SetPoint("TOPLEFT",425,-42)
priorityTitle:SetText("Stat priorities")
local priorityUI={modes={},weights={},refreshing=false}
priorityUI.help=NewText(settings,"GameFontHighlightSmall",325)
priorityUI.help:SetPoint("TOPLEFT",425,-112)
local priorityDescriptions={balanced="Uses class and talent-aware stat priorities.",
    priority="Gives your chosen stat greater importance.",custom="Set your own stat weights."}
for index,mode in ipairs({"balanced","priority","custom"}) do
    local button=NewButton(settings,({balanced="Balanced",priority="Priority",custom="Advanced"})[mode],104,25)
    button:SetPoint("TOPLEFT",425+(index-1)*110,-76)
    priorityUI.modes[mode]=button
end
priorityUI.stat=NewButton(settings,"",325,25)
priorityUI.stat:SetPoint("TOPLEFT",425,-150)
priorityUI.heading=NewText(settings,"GameFontHighlightSmall",325)
priorityUI.heading:SetPoint("TOPLEFT",425,-150)
priorityUI.heading:SetText("Weights (0–1000)")
priorityUI.scroll=CreateFrame("ScrollFrame","GetGear_PriorityWeights",settings,"UIPanelScrollFrameTemplate")
priorityUI.scroll:SetPoint("TOPLEFT",425,-174)
priorityUI.scroll:SetSize(325,420)
priorityUI.content=CreateFrame("Frame",nil,priorityUI.scroll)
priorityUI.content:SetSize(325,420)
priorityUI.scroll:SetScrollChild(priorityUI.content)
priorityUI.scroll:EnableMouseWheel(true)
priorityUI.scroll:SetScript("OnMouseWheel",function(self,delta)
    local maximum=math.max(0,priorityUI.content:GetHeight()-self:GetHeight())
    self:SetVerticalScroll(math.max(0,math.min(maximum,self:GetVerticalScroll()-delta*30)))
end)
priorityUI.message=NewText(settings,"GameFontHighlightSmall",325)
priorityUI.message:SetPoint("TOPLEFT",425,-602)
local function UpdateWeightMessage()
    for _,widget in pairs(priorityUI.weights) do
        if widget.owner==GetGear.db and widget.invalid then
            priorityUI.message:SetText("Enter a finite number from 0 to 1000. Invalid weights were not changed.")
            return
        end
    end
    priorityUI.message:SetText("")
end
local function SetWeightText(widget,value)
    widget.rendering=true
    widget.dirty=false;widget.invalid=false
    widget.edit:SetText(tostring(value))
    widget.edit:SetTextColor(1,1,1)
    widget.rendering=false
end
local function SavePriorityWeight(widget)
    if priorityUI.refreshing or not widget.dirty then return true end
    -- A focus event from the previous character must never write to this one.
    if widget.owner~=GetGear.db or GetGear:GetStatPriorityMode()~="custom" then return false end
    local value=tonumber(widget.edit:GetText())
    if not GetGear:SetCustomStatWeight(widget.key,value) then
        widget.invalid=true;widget.edit:SetTextColor(1,0.4,0.4)
        UpdateWeightMessage();return false
    end
    SetWeightText(widget,value);UpdateWeightMessage()
    return true
end
local function CommitPriorityWeights()
    for _,widget in pairs(priorityUI.weights) do SavePriorityWeight(widget) end
end
for _,definition in ipairs(GetGear.StatPriorityDefinitions) do
    local key=definition[1]
    local widget={key=key,label=NewText(priorityUI.content,"GameFontHighlightSmall",102)}
    widget.label:SetText(definition[2]);widget.label:SetHeight(28)
    widget.edit=CreateFrame("EditBox","GetGear_StatWeight_"..key,priorityUI.content,"InputBoxTemplate")
    widget.edit:SetSize(48,24)
    widget.edit:SetAutoFocus(false);widget.edit:SetMaxLetters(12)
    widget.edit:SetScript("OnTextChanged",function()
        if not widget.rendering and not priorityUI.refreshing then widget.dirty=true end
    end)
    widget.edit:SetScript("OnEnterPressed",function(self)
        if SavePriorityWeight(widget) then self:ClearFocus() end
    end)
    widget.edit:SetScript("OnEditFocusLost",function() SavePriorityWeight(widget) end)
    widget.edit:SetScript("OnEscapePressed",function(self)
        if widget.owner==GetGear.db then
            local p=GetGear:InitializeStatPriorities()
            SetWeightText(widget,p.weights[key] or 0);UpdateWeightMessage()
        end
        self:ClearFocus()
    end)
    priorityUI.weights[key]=widget
end
local function RefreshPrioritySettings()
    local p=GetGear:InitializeStatPriorities();if not p then return end
    priorityUI.refreshing=true
    priorityUI.help:SetText(priorityDescriptions[p.mode])
    for mode,button in pairs(priorityUI.modes) do button:SetEnabled(mode~=p.mode) end
    priorityUI.stat:SetText("Priority: "..p.priority)
    for _,widget in pairs(priorityUI.weights) do
        widget.edit:ClearFocus()
        widget.edit:Hide();widget.label:Hide()
        widget.owner=GetGear.db
        SetWeightText(widget,p.weights[widget.key] or 0)
    end
    local stats=GetGear:GetSupportedPriorityStats()
    for index,definition in ipairs(stats) do
        if definition[1]==p.priority then priorityUI.stat:SetText("Priority: "..definition[2]) end
        local widget=priorityUI.weights[definition[1]]
        local x=((index-1)%2)*166
        local y=math.floor((index-1)/2)*30
        widget.label:ClearAllPoints();widget.label:SetPoint("TOPLEFT",x,-y-2)
        widget.edit:ClearAllPoints();widget.edit:SetPoint("TOPLEFT",x+108,-y)
        if p.mode=="custom" then widget.label:Show();widget.edit:Show() end
    end
    priorityUI.content:SetHeight(math.max(420,math.ceil(#stats/2)*30))
    priorityUI.scroll:SetVerticalScroll(0)
    priorityUI.scroll:SetShown(p.mode=="custom")
    priorityUI.heading:SetShown(p.mode=="custom")
    priorityUI.stat:SetShown(p.mode=="priority")
    priorityUI.message:SetText("")
    priorityUI.refreshing=false
end
for mode,button in pairs(priorityUI.modes) do
    local selectedMode=mode
    button:SetScript("OnClick",function()
        CommitPriorityWeights()
        GetGear:SetStatPriorityMode(selectedMode)
        RefreshPrioritySettings()
    end)
end
priorityUI.stat:SetScript("OnClick",function()
    local stats=GetGear:GetSupportedPriorityStats();local index=0
    local p=GetGear:InitializeStatPriorities()
    for i,definition in ipairs(stats) do if definition[1]==p.priority then index=i;break end end
    if #stats>0 then GetGear:SetPriorityStat(stats[index%#stats+1][1]) end
    RefreshPrioritySettings()
end)
local resetPriorities=NewButton(settings,"Reset to defaults",230,24)
resetPriorities:SetPoint("BOTTOMLEFT",425,18)
resetPriorities:SetScript("OnClick",function() GetGear:ResetStatPriorities();RefreshPrioritySettings() end)
settings:HookScript("OnHide",CommitPriorityWeights)
local closeSettings=NewButton(settings,"Close",88,24)
closeSettings:SetPoint("BOTTOMRIGHT",-18,18)
closeSettings:SetScript("OnClick",function() settings:Hide() end)

function GetGear:ShowSettings()
    if not self.db then return end
    CommitPriorityWeights()
    RefreshPrioritySettings()
    LayoutDisplayChecks()
    FitSettingsToScreen()
    -- Within DIALOG, put settings above the detailed guide while it is open.
    settings:SetFrameLevel(math.max(settings:GetFrameLevel(), window:GetFrameLevel() + 20))
    settings:Show()
    if type(settings.Raise) == "function" then settings:Raise() end
    materialScopeButton:SetText("Materials: " .. (self.db.overlay.materialScope == "all" and "All" or "Tracked"))
    lockedCheck:SetChecked(self.db.overlay.locked)
    combatCheck:SetChecked(self.db.overlay.hideInCombat)
    obsoleteCheck:SetChecked(self.db.overlay.filterObsolete ~= false)
    bagsCheck:SetChecked(self.db.overlay.bagUpgrades ~= false)
    craftFilterCheck:SetChecked(self.db.overlay.hideUncraftableCrafts == true)
    allValidGearCheck:SetChecked(self.db.overlay.showAllValidGear == true)
    positiveStatCheck:SetChecked(self.db.overlay.hideWithoutPositiveStats ~= false)
    greenBoECheck:SetChecked(self.db.overlay.hideGreenBoEWorldDrops ~= false)
    armorOnlyCheck:SetChecked(self.db.overlay.countArmorOnlyUpgrades == true)
    alphaSlider:SetValue(math.floor((self.db.overlay.backgroundOpacity or 0.78)*100 + 0.5))
    overlayScaleSlider:SetValue(math.floor((self.db.overlay.scale or 1)*100+0.5))
    detailScaleSlider:SetValue(math.floor((self.db.detail.scale or 1)*100+0.5))
end

function GetGear:InitializeUI()
    if not self.db then return end
    local opts=self.db.overlay
    local detail=self.db.detail or {}
    overlay:SetScale(math.max(0.7,math.min(1.5,opts.scale or 1)))
    window:SetScale(math.max(0.7,math.min(1.5,detail.scale or 1)))
    if type(opts.width)=="number" then overlay:SetWidth(math.max(320,math.min(580,opts.width))) end
    if type(opts.height)=="number" then overlay:SetHeight(math.max(230,math.min(950,opts.height))) end
    if type(opts.x)=="number" and type(opts.y)=="number" then
        overlay:ClearAllPoints()
        overlay:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",opts.x,opts.y)
    end
    if type(detail.width)=="number" and type(detail.height)=="number" then
        window:SetSize(math.max(720,math.min(1260,detail.width)),math.max(400,math.min(1000,detail.height)))
    end
    if type(detail.x)=="number" and type(detail.y)=="number" then
        window:ClearAllPoints()
        window:SetPoint("TOPLEFT",UIParent,"BOTTOMLEFT",detail.x,detail.y)
    end
    self:RefreshOverlay()
end

-- Zero-dependency minimap button: click for detailed guide, shift-click overlay.
local minimapButton=CreateFrame("Button", "GetGear_MinimapButton",Minimap)
minimapButton:SetSize(30,30)
minimapButton:SetPoint("TOPLEFT",Minimap,"TOPLEFT",-9,2)
local minimapTexture=minimapButton:CreateTexture(nil,"ARTWORK")
minimapTexture:SetAllPoints()
minimapTexture:SetTexture("Interface\\Icons\\INV_Misc_Book_09")
minimapButton:SetScript("OnClick",function()
    if type(IsShiftKeyDown)=="function" and IsShiftKeyDown() then GetGear:ToggleOverlay()
    else GetGear:ToggleUI() end
end)
minimapButton:SetScript("OnEnter",function(self)
    GameTooltip:SetOwner(self,"ANCHOR_LEFT")
    GameTooltip:AddLine("GetGear")
    GameTooltip:AddLine("Click: toggle detailed guide",1,1,1)
    GameTooltip:AddLine("Shift-click: show/hide overlay",1,1,1)
    GameTooltip:Show()
end)
minimapButton:SetScript("OnLeave",HideItemTooltip)

-- Search opens over the tracker and releases its space on dismissal. The
-- focused card is a separate browsing context, never a recommendation override.
function GetGear:InitializeItemSearchUI()
    local search=NewButton(overlay,"",24,22)
    search:SetPoint("TOPLEFT",147,-5)
    local glass=search:CreateTexture(nil,"ARTWORK")
    glass:SetAllPoints()
    glass:SetTexture("Interface\\Common\\UI-Searchbox-Icon")
    trackerLevel:SetWidth(math.max(90,overlay:GetWidth()-218))
    local popup=CreateFrame("Frame","GetGear_ItemSearch",overlay)
    popup:SetSize(312,405)
    popup:SetPoint("TOPLEFT",overlay,"TOPLEFT",0,-32)
    popup:SetFrameStrata("DIALOG")
    popup:SetClampedToScreen(true);popup:EnableMouse(true)
    local bg=popup:CreateTexture(nil,"BACKGROUND");bg:SetAllPoints();bg:SetColorTexture(.045,.065,.10,1)
    local edit=CreateFrame("EditBox","GetGear_ItemSearchInput",popup,"InputBoxTemplate")
    edit:SetSize(258,24);edit:SetPoint("TOPLEFT",12,-9);edit:SetAutoFocus(false);edit:SetMaxLetters(80)
    if edit.SetAltArrowKeyMode then edit:SetAltArrowKeyMode(false) end
    local close=NewButton(popup,"X",24,22);close:SetPoint("TOPRIGHT",-7,-9)
    local hint=NewText(popup,"GameFontHighlightSmall",290);hint:SetPoint("TOPLEFT",10,-40)
    local rows,results,selected={}, {},1
    local focus=CreateFrame("Frame",nil,popup);focus:SetPoint("TOPLEFT",8,-60);focus:SetSize(294,330)
    local glow=focus:CreateTexture(nil,"BACKGROUND");glow:SetAllPoints();glow:SetColorTexture(.45,.32,.07,.8)
    local focusIcon=NewIcon(focus,32);focusIcon:SetPoint("TOPLEFT",8,-8)
    local title=NewText(focus,"GameFontNormal",210);title:SetPoint("TOPLEFT",46,-8)
    local star=wishlistUI.NewStarButton(focus);star:SetPoint("TOPRIGHT",-6,-6)
    local state=NewText(focus,"GameFontHighlightSmall",278);state:SetPoint("TOPLEFT",8,-47)
    local bodyScroll=CreateFrame("ScrollFrame",nil,focus,"UIPanelScrollFrameTemplate")
    bodyScroll:SetPoint("TOPLEFT",8,-85);bodyScroll:SetPoint("BOTTOMRIGHT",-28,38)
    local bodyContent=CreateFrame("Frame",nil,bodyScroll);bodyContent:SetSize(248,200);bodyScroll:SetScrollChild(bodyContent)
    local description=NewText(bodyContent,"GameFontHighlightSmall",246);description:SetPoint("TOPLEFT",0,0)
    local pin=NewAcquisitionPin(focus,24);pin:SetPoint("BOTTOMLEFT",8,6)
    local manage=NewButton(focus,"Hide",74,22);manage:SetPoint("BOTTOMLEFT",40,6)
    local done=NewButton(focus,"Acquired",80,22);done:SetPoint("BOTTOMLEFT",118,6)
    local skip=NewButton(focus,"Skip",74,22);skip:SetPoint("BOTTOMRIGHT",-6,6)
    local focused
    local function dismiss()
        popup:Hide();edit:ClearFocus();focused=nil;self.focusedSearchItem=nil
    end
    close:SetScript("OnClick",dismiss)
    popup:SetScript("OnHide",function() edit:ClearFocus();focused=nil;self.focusedSearchItem=nil end)
    overlay:HookScript("OnHide",dismiss)
    if UISpecialFrames then table.insert(UISpecialFrames,"GetGear_ItemSearch") end
    local resultScroll=CreateFrame("ScrollFrame",nil,popup,"UIPanelScrollFrameTemplate")
    resultScroll:SetPoint("TOPLEFT",8,-60);resultScroll:SetPoint("BOTTOMRIGHT",-28,10)
    local resultContent=CreateFrame("Frame",nil,resultScroll)
    resultContent:SetSize(264,320);resultScroll:SetScrollChild(resultContent)
    for i=1,6 do
        local row=NewButton(resultContent,"",264,54)
        row:SetPoint("TOPLEFT",10,-60-(i-1)*56)
        row.label=NewText(row,"GameFontHighlightSmall",256);row.label:SetPoint("TOPLEFT",4,-32)
        row.star=wishlistUI.NewStarButton(row);row.star:SetPoint("TOPRIGHT",-4,-4)
        row:SetScript("OnClick",function()
            local result=results[i]
            if not result then return end
            local ok,reason=self:SelectSearchItem(result.itemID)
            if not ok then hint:SetText(reason) end
        end)
        rows[i]=row
    end
    local function refreshFocus(recalculate)
        if not focused then return end
        local record=self:GetSearchRecord(focused.itemID)
        local reason=self:GetSearchRestriction(record,true)
        if reason then
            title:SetText(record and record.name or "Item unavailable")
            state:SetText(reason);description:SetText("");pin:Hide();manage:Hide();done:Hide();skip:Hide()
            wishlistUI.AssignStar(star,focused,false)
            return
        end
        focused=self:GetRecommendationRecord(record)
        local gear=focused
        title:SetText((gear.name or "Unnamed item").."\n"..(gear.slot or "Unknown slot"))
        local titleHeight=MeasureText(title,32)
        state:ClearAllPoints();state:SetPoint("TOPLEFT",8,-titleHeight-16)
        bodyScroll:ClearAllPoints();bodyScroll:SetPoint("TOPLEFT",8,-titleHeight-54);bodyScroll:SetPoint("BOTTOMRIGHT",-28,38)
        state:SetText("Level "..tostring(gear.targetLevel).." | "..self:GetSearchItemState(gear))
        wishlistUI.AssignStar(star,gear,false)
        if recalculate then
            SetItemIcon(focusIcon,gear.itemID,nil,nil,gear)
            local comparison=self:ComparisonInline(gear,false)
            local summary=self:GetAcquisitionSummary(gear) or "Acquisition information uncertain."
            description:SetText(summary.."\n\n"..Describe(gear,false)..(comparison and comparison~="" and ("\n\n"..comparison) or ""))
            bodyContent:SetHeight(math.max(190,MeasureText(description,24)+12))
            bodyScroll:SetVerticalScroll(0)
            AssignAcquisitionPin(pin,gear)
        end
        manage:Show();done:Show();skip:Show()
        local status=self:GetStatus(gear)
        manage:SetText(self:IsHidden(gear) and "Restore" or "Hide")
        manage:SetScript("OnClick",function() self:SetHidden(gear,not self:IsHidden(gear));refreshFocus(true) end)
        done:SetText(status=="acquired" and "Undo" or "Acquired")
        done:SetScript("OnClick",function() if status=="acquired" then self:SetStatus(gear,nil) else self:SetStatus(gear,"acquired") end;refreshFocus(true) end)
        skip:SetText(status=="skipped" and "Undo skip" or "Skip")
        skip:SetScript("OnClick",function() if status=="skipped" then self:SetStatus(gear,nil) else self:SetStatus(gear,"skipped") end;refreshFocus(true) end)
    end
    function self:ShowSearchFocus(record)
        popup:Show();resultScroll:Hide();focused=record
        hint:SetText("Search focus | "..(record.slot or "Equipment"))
        for _,row in ipairs(rows) do row:Hide() end
        focus:Show();glow:SetColorTexture(.45,.32,.07,.8);refreshFocus(true)
        local identity=record
        if C_Timer and C_Timer.After then C_Timer.After(6,function()
            if focused and focused.itemID==identity.itemID then glow:SetColorTexture(.10,.13,.19,.95) end
        end) end
    end
    local function drawResults()
        focus:Hide();resultScroll:Show()
        local resultY=0
        hint:SetText(#results==0 and (edit:GetText()=="" and "Search equipment by name" or "No matching equipment.")
            or "Enter: locate | Arrows: choose | Escape: close")
        for i,row in ipairs(rows) do
            local result=results[i]
            if result then
                local gear=result.record
                local eligibility=self.EquipmentEligibility and self.EquipmentEligibility[result.itemID]
                local level=eligibility and eligibility[2] or gear.requiredLevel or gear.targetLevel or gear.availableLevel or "?"
                local name=gear.name or ("Item "..result.itemID)
                local status=result.restriction or self:GetSearchItemState(gear)
                if #status>36 then status=status:sub(1,33).."..." end
                row.itemID,row.gearRecord=result.itemID,gear
                row:SetScript("OnEnter",ShowItemTooltip);row:SetScript("OnLeave",HideItemTooltip)
                row.label:SetText((selected==i and "> " or "")..name.."\nLevel "..level.." | "..(gear.slot or "Unknown slot").."\n"..status)
                wishlistUI.AssignStar(row.star,gear,false)
                row.star:SetEnabled(not result.restriction or self:IsItemStarred(result.itemID))
                row:ClearAllPoints();row:SetPoint("TOPLEFT",resultContent,"TOPLEFT",0,-resultY)
                row:SetHeight(MeasureText(row.label,36)+38)
                resultY=resultY+row:GetHeight()+4
                row:Show()
            else row:Hide() end
        end
        resultContent:SetHeight(math.max(1,resultY))
        wishlistUI.CommitScrollLayout(resultScroll)
    end
    edit:SetScript("OnTextChanged",function()
        focused=nil;self.focusedSearchItem=nil;selected=1
        resultScroll:SetVerticalScroll(0)
        results=self:SearchEquipment(edit:GetText(),6);drawResults()
    end)
    edit:SetScript("OnEnterPressed",function()
        if results[selected] then
            local ok,reason=self:SelectSearchItem(results[selected].itemID)
            if not ok then hint:SetText(reason) end
        end
    end)
    edit:SetScript("OnEscapePressed",dismiss)
    edit:SetScript("OnArrowPressed",function(_,key)
        if focused then return end
        if key=="UP" then selected=math.max(1,selected-1)
        elseif key=="DOWN" then selected=math.min(#results,selected+1) end
        drawResults()
        local top=0
        for i=1,selected-1 do top=top+rows[i]:GetHeight()+4 end
        local bottom=top+(rows[selected] and rows[selected]:GetHeight() or 0)
        local offset=resultScroll:GetVerticalScroll()
        local height=resultScroll:GetHeight()
        if top<offset then resultScroll:SetVerticalScroll(top)
        elseif bottom>offset+height then resultScroll:SetVerticalScroll(math.max(0,bottom-height)) end
    end)
    function self:RefreshItemSearchUI(recalculate)
        if not popup:IsShown() then return end
        if focused then
            if recalculate then refreshFocus(true) else wishlistUI.AssignStar(star,focused,false) end
        else drawResults() end
    end
    search:SetScript("OnClick",function()
        if popup:IsShown() then dismiss() else
            popup:Show();focus:Hide();edit:SetText("");results={};drawResults()
            if edit.SetFocus then edit:SetFocus() end
        end
    end)
    search:SetScript("OnEnter",function(button)
        if GameTooltip then GameTooltip:SetOwner(button,"ANCHOR_BOTTOM");GameTooltip:AddLine("Search equipment");GameTooltip:Show() end
    end)
    search:SetScript("OnLeave",HideItemTooltip)
    popup:Hide()
end
GetGear:InitializeItemSearchUI()
